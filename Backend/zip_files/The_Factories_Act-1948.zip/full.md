# THE FACTORIES ACT, 1948

# ARRANGEMENT OF SECTIONS

# CHAPTER I PRELIMINARY

## SECTIONS

1. Short title, extent and commencement.

2. Interpretation.

3. References to time of day.

4. Power to declare different departments to be separate factories or two or more factories to be a single factory.

5. Power to exempt during public emergency.

6. Approval, licensing and registration of factories.

7. Notice by occupier.

## CHAPTER II

## THE INSPECTING STAFF

7A. General duties of the occupier.

7B. General duties of manufacturers, etc., as regards articles and substances for use in factories.

8. Inspectors.

9. Powers of Inspectors.

10. Certifying surgeons.

11. Cleanliness.

12. Disposal of wastes and effluents.

13. Ventilation and temperature.

14. Dust and fume.

15. Artificial humidification.

16. Overcrowding.

17. Lighting.

## CHAPTER III

18. Drinking water.

19. Latrines and urinals.

20. Spittoons.

HEALTH

## CHAPTER IV

SAFETY

21. Fencing of machinery.

22. Work on or near machinery in motion.

## SECTIONS

23. Employment of young persons on dangerous machines.

24. Striking gear and devices for cutting off power.

25. Self-acting machines.

26. Casing of new machinery.

27. Prohibition of employment of women and children near cotton-openers.

28. Hoists and lifts.

29. Lifting machines, chains, ropes and lifting tackles.

30. Revolving machinery.

31. Pressure plant.

32. Floors, stairs and means of access.

33. Pits, sumps openings in floors, etc.

34. Excessive weights.

35. Protection of eyes.

36. Precautions against dangerous fumes, gases, etc.

36A. Precautions regarding the use of portable electric light.

37. Explosive or inflammable dust, gas, etc.

38. Precautions in case of fire.

39. Power to require specifications of defective parts or tests of stability.

40. Safety of buildings and machinery.

40A. Maintenance of buildings.

40B. Safety officers.

41. Power to make rules to supplement this Chapter.

## CHAPTER IVA

## PROVISIONS RELATING TO HAZARDOUS PROCESSES

41A. Constitution of Site Appraisal Committee.

41B. Compulsory disclosure of information by the occupier.

41C. Specific responsibility of the occupier in relation to hazardous processes.

41D. Power of Central Government to appoint Inquiry Committee.

41E. Emergency standards.

41F. Permissible limits of exposure of chemical and toxic substances.

41G. Workers’ participation in safety management.

41H. Right of workers to warn about imminent danger.

CHAPTER V

WELFARE

42. Washing facilities.

43. Facilities for storing and drying clothing.

## SECTIONS

44. Facilities for sitting.

45. First-aid appliances.

46. Canteens.

47. Shelters, rest rooms and lunch rooms.

48. Creches.

49. Welfare officers.

50. Power to make rules to supplement this Chapter.

## CHAPTER VI WORKING HOURS OF ADULTS

51. Weekly hours.

52. Weekly holidays.

53. Compensatory holidays.

54. Daily hours.

55. Intervals for rest.

56. Spread over.

57. Night shifts.

58. Prohibition of overlapping shifts.

59. Extra wages for overtime.

60. Restriction on double employment.

61. Notice of periods of work for adults.

62. Register of adult workers.

63. Hours of work to correspond with notice under section 61 and register under section 62.

64. Power to make exempting rules.

65. Power to make exempting orders.

66. Further restrictions on employment of women.

## CHAPTER VII EMPLOYMENT OF YOUNG PERSONS

67. Prohibition of employment of young children.

68. Non-adult workers to carry tokens.

69. Certificates of fitness.

70. Effect of certificate of fitness granted to adolescent.

71. Working hours for children.

72. Notice of periods of work for children.

73. Register of child workers.

74. Hours of work to correspond with notice under section 72 and register under section 73.

75. Power to require medical examination.

76. Power to make rules.

77. Certain other provisions of law not barred.

# CHAPTER VIII ANNUAL LEAVE WITH WAGES

## SECTIONS

78. Application of Chapter.

79. Annual leave with wages.

80. Wages during leave period.

81. Payment in advance in certain cases.

82. Mode of recovery of unpaid wages.

83. Power to make rules.

84. Power to exempt factories.

## CHAPTER IX

## SPECIAL PROVISIONS

85. Power to apply the Act to certain premises.

86. Power to exempt public institutions.

87. Dangerous operations.

87A. Power to prohibit employment on account of serious hazard.

88. Notice of certain accidents.

88A. Notice of certain dangerous occurrences.

89. Notice of certain diseases.

90. Power to direct enquiry into cases of accident or disease.

91. Power to take samples.

91A. Safety and occupational health surveys.

## CHAPTER X

## PENALTIES AND PROCEDURE

92. General penalty for offences.

93. Liability of owner of premises in certain circumstances.

94. Enhanced penalty after previous conviction.

95. Penalty for obstructing Inspector.

96. Penalty for wrongfully disclosing results of analysis under section 91.

96A. Penalty for contravention of the provisions of sections 41B, 41C and 41H.

97. Offences by workers.

98. Penalty for using false certificate of fitness.

99. Penalty for permitting double employment of child.

100. [Repealed.]

101. Exemption of occupier or manager from liability in certain cases.

102. Power of Court to make orders.

103. Presumption as to employment.

104. Onus as to age.

## SECTIONS

104A. Onus of proving limits of what is practicable, etc.

105. Cognizance of offences.

106. Limitation of prosecutions.

106A. Jurisdiction of a court for entertaining proceedings, etc., for offence.

## CHAPTER XI SUPPLEMENTAL

107. Appeals.

108. Display of notices.

109. Service of notices.

110. Returns.

111. Obligations of workers.

111A. Right of workers, etc.

112. General power to make rules.

113. Powers of Centre to give directions.

114. No charge for facilities and conveniences.

115. Publication of rules.

116. Application of Act to Government factories.

117. Protection to persons acting under this Act.

118. Restrictions on disclosure of information.

118A. Restriction on disclosure of information.

119. Act to have effect notwithstanding anything contained in Act 37 of 1970.

120. Repeal and savings.

THE FIRST SCHEDULE.

THE SECOND SCHEDULE.

THE THIRD SCHEDULE.

# THE FACTORIES ACT, 1948 ACT NO. 63 OF 1948<sup>1</sup>

[23rd September, 1948.]

An Act to consolidate and amend the law regulating labour in factories.

WHEREAS it is expedient to consolidate and amend the law regulating labour in factories;

It is hereby enacted as follows:—

## CHAPTER I

## PRELIMINARY

1. Short title, extent and commencement.—(1) This Act may be called the Factories Act, 1948.

<sup>2</sup>[(2) It extends to the whole of India <sup>3</sup>\*\*\*.]

(3) It shall come into force on the 1st day of April 1949.

2. Interpretation.—In this Act, unless there is anything repugnant in the subject or context,—

(a) “adult” means a person who has completed his eighteenth year of age;

(b) “adolescent” means a person who has completed his fifteenth year of age but has not completed his eighteenth year;

<sup>4</sup>[(bb) “calendar year” means the period of twelve months beginning with the first day of January in any year;]

(c) “child” means a person who has not completed his fifteenth year of age;

<sup>5</sup>[(ca) “competent person”, in relation to any provision of this Act, means a person or an institution recognised as such by the Chief Inspector for the purposes of carrying out tests, examinations and inspections required to be done in a factory under the provisions of this Act having regard to—

(i) the qualifications and experience of the person and facilities available at his disposal; or

(ii) the qualifications and experience of the persons employed in such institution and facilities available therein,

with regard to the conduct of such tests, examinations and inspections, and more than one person or institution can be recognised as a competent person in relation to a factory;

(cb) “hazardous process” means any process or activity in relation to an industry specified in the First Schedule where, unless special care is taken, raw materials used therein or the intermediate or finished products, bye-products, wastes or effluents thereof would—

(i) cause material impairment to the health of the persons engaged in or connected therewith, or

(ii) result in the pollution or the general environment:

Provided that the State Government may, by notification in the Official Gazette, amend the First Schedule by way of addition, omission or variation of any industry specified in the said Schedule;]

(d) “young person” means a person who is either a child or an adolescent;

(e) “day” means a period of twenty-four hours beginning at midnight;

(f) “week” means a period of seven days beginning at midnight on Saturday night or such other night as may be approved in writing for a particular area by the Chief Inspector of Factories;

(g) “power” means electrical energy, or any other form of energy which is mechanically transmitted and is not generated by human or animal agency;

(h) “prime mover” means any engine, motor or other appliance which generates or otherwise provides power;

(i) “transmission machinery” means any shaft, wheel, drum, pulley, system of pulleys, coupling, clutch, driving belt or other appliance or device by which the motion of a prime mover is transmitted to or received by any machinery or appliance;

(j) ”machinery” includes prime movers, transmission machinery and all other appliances whereby power is generated, transformed, transmitted or applied;

(k) “manufacturing process” means any process for—

(i) making, altering, repairing, ornamenting, finishing, packing, oiling, washing, cleaning, breaking up, demolishing, or otherwise treating or adapting any article or substance with a view to its use, sale, transport, delivery or disposal; or

<sup>1</sup>[(ii) pumping oil, water, sewage or any other substance; or]

(iii) generating, transforming or transmitting power; or

<sup>2</sup>[(iv) composing types for printing, printing by letter press, lithography, photogravure or other similar process or book binding; <sup>3</sup>[or]]

(v) constructing, reconstructing, repairing, refitting, finishing or breaking up ships or vessels; <sup>3</sup>[or]

<sup>3</sup>[(vi) preserving or storing any article in cold storage;]

(l) “worker” means a person [employed, directly or by or through any agency (including a contractor) with or without the knowledge of the principal employer, whether for remuneration or not], in any manufacturing process, or in cleaning any part of the machinery or premises used for a manufacturing process, or in any other kind of work incidental to, or connected with, the manufacturing process, or the subject of the manufacturing process <sup>3</sup>[but does not include any member of the armed forces of the Union];

(m) “factory” means any premises including the precincts thereof—

(i) whereon ten or more workers are working, or were working on any day of the preceding twelve months, and in any part of which a manufacturing process is being carried on with the aid of power, or is ordinarily so carried on, or

(ii) whereon twenty or more workers are working, or were working on any day of the preceding twelve months, and in any part of which a manufacturing process is being carried on without the aid of power, or is ordinarily so carried on,—

but does not include a mine subject to the operation of <sup>5</sup>[the Mines Act, 1952 (35 of 1952)], or <sup>6</sup>[a mobile mobile unit belonging to the armed forces of the Union, railway running shed or a hotel, restaurant or eating place].

<sup>1</sup>[Explanation <sup>2</sup>[I]—For computing the number of workers for the purposes of this clause all the workers in <sup>3</sup>[different groups and relays] in a day shall be taken into account;]

<sup>4</sup>[Explanation II.—For the purposes of this clause, the mere fact that an Electronic Data Processing Unit or a Computer Unit is installed in any premises or part thereof, shall not be construed to make it a factory if no manufacturing process is being carried on in such premises or part thereof;]

(n) “occupier” of a factory means the person who has ultimate control over the affairs of the factor y <sup>5</sup>\*\*\*.

<sup>4</sup>[Provided that—

(i) in the case of a firm or other association of individuals, any one of the individual partners or members thereof shall be deemed to be the occupier;

(ii) in the case of a company, any one of the directors shall be deemed to be the occupier;

(iii) in the case of a factory owned or controlled by the Central Government or any State Government, or any local authority, the person or persons appointed to manage the affairs of the factory by the Central Government, the Stale Government or the local authority, as the case may be, shall be deemed to be the occupier:]

<sup>1</sup>[<sup>6</sup>[Provided further that] in the case of a ship which is being repaired, or on which maintenance work is being carried out, in a dry dock which is available for hire,—

(1) the owner of the dock shall be deemed to be the occupier for the purposes of any matter provided for by or under—

(a) section 6, section 7, <sup>4</sup>[section 7A, section 7B,] section 11 or section 12;

(b) section 17, in so far as it relates to the providing and maintenance of sufficient and suitable lighting in or around the dock;

(c) section 18, section 19, section 42, section 46, section 47 or section 49, in relation to the workers employed on such repair or maintenance;

(2) the owner of the ship or his agent or master or other officer-in-charge of the ship or any person who contracts with such owner, agent or master or other officer-in-charge to carry out the repair or maintenance work shall be deemed to be the occupier for the purposes of any matter provided for by or under section 13, section 14, section 16 or section 17 (save as otherwise provided in this proviso) or Chapter IV (except section 27) or section 43, section 44 or section 45, Chapter VI, Chapter VII, Chapter VIII or Chapter IX or section 108, section 109 or section 110, in relation to—

(a) the workers employed directly by him, or by or through any agency; and

(b) the machinery, plant or premises in use for the purpose of carrying out such repair or maintenance work by such owner, agent, master or other officer-in-charge or person;

7 \* \* \* \*

(p) “prescribed” means prescribed by rules made by the State Government under this Act; 8 \* \* \* \*

(r) where work of the same kind is carried out by two or more sets of workers working during different periods of the day, each of such sets is called a <sup>9</sup>[“group” or “relay”] and each of such periods is called a “shift”.

3. References to time of day.—In this Act references to time of day are references to Indian Standard Time, being five and a half hours ahead of Greenwich Mean Time:

Provided that for any area in which Indian Standard Time is not ordinarily observed the State Government may make rules—

(a) specifying the area,

(b) defining the local mean time ordinarily observed therein, and

(c) permitting such time to be observed in all or any of the factories situated in the area.

<sup>1</sup>[4. Power to declare different departments to be separate factories or two or more factories to be a single factory.—The State Government may, <sup>2</sup>[on its own or] on an application made in this behalf by an occupier, direct, by an order in writing [and subject to such conditions as it may deem fit that for all or any of the purposes of this Act different departments or branches of a factory of the occupier specified in the application shall be treated as separate factories or that two or more factories of the occupier specified in the application shall be treated as a single factory:]

<sup>3</sup>[Provided that no order under this section shall be made by the State Government on its own motion unless an opportunity of being heard is given to the occupier.]

5. Power to exempt during public emergency.—In any case of public emergency the State Government may, by notification in the Official Gazette, exempt any factory or class or description of factories from all or any of the provisions of this Act <sup>4</sup>[except section 67] for such period and subject to such conditions as it may think fit:

Provided that no such notification shall be made for a period exceeding three months at a time.

<sup>5</sup>[Explanation.—For the purposes of this section “public emergency” means a grave emergency whereby the security of India or of any part of the territory thereof is threatened, whether by war or external aggression or internal disturbance.]

6. Approval, licensing and registration of factories.—(1) The State Government may make rules—

<sup>6</sup>[(a) requiring, for the purposes of this Act, the submission of plans of any class or description of factories to the Chief Inspector or the State Government;]

<sup>7</sup>[(aa)] requiring, the previous permission in writing of the State Government or the Chief Inspector to be obtained for the site on which the factory is to be situated and for the construction or extension of any factory or class or description of factories;

(b) requiring for the purpose of considering applications for such permission the submission of plans and specifications;

(c) prescribing the nature of such plans and specifications and by whom they shall be certified;

(d) requiring the registration and licensing of factories or any class or description of factories, and prescribing the fees payable for such registration and licensing and for the renewal of licences;

(e) requiring that no licence shall be granted or renewed unless the notice specified in section 7 has been given.

(2) If on an application for permission referred to in <sup>8</sup>[clause (aa)] of sub-section (1) accompanied by the plans and specifications required by the rules made under clause (b) of that sub-section, sent to the State Government or Chief Inspector by registered post, no order is communicated to the applicant within three months from the date on which it is so sent, the permission applied for in the said application shall be deemed to have been granted.

(3) Where a State Government or a Chief Inspector refuses to grant permission to the site, construction or extension of a factory or to the registration and licensing of a factory, the applicant may within thirty days of the date of such refusal appeal to the Central Government if the decision appealed from was of the State Government and to the State Government in any other case.

Explanation.—A factory shall not be deemed to be extended within the meaning of this section by reason only of the replacement of any plant or machinery, or within such limits as may be prescribed, of the addition of any plant or machinery <sup>1</sup>[if such replacement or addition does not reduce the minimum clear space required for safe working around the plant or machinery or adversely affect the environmental conditions from the evolution or emission of steam, heat or dust or fumes injurious to health].

7. Notice by occupier.—(1) The occupier shall, at least fifteen days before he begins to occupy or use any premises as a factory, send to the Chief Inspector a written notice containing—

(a) the name and situation of the factory;

(b) the name and address of the occupier;

<sup>2</sup>[(bb) the name and address of the owner of the premises or building (including the precincts thereof) referred to in section 93;]

(c) the address to which communications relating to the factory may be sent;

(d) the nature of the manufacturing process—

(i) carried on in the factory during the last twelve months in the case of factories in existence on the date of the commencement of this Act; and

(ii) to be carried on in the factory during the next twelve months in the case of all factories;

<sup>3</sup>[(e) the total rated horse power installed or to be installed in the factory, which shall not include the rated horse power of any separate stand-by plant;]

(f) the name of the manager of the factory for the purposes of this Act;

(g) the number of workers likely to be employed in the factory;

(h) the average number of workers per day employed during the last twelve months in the case of a factory in existence on the date of the commencement of this Act;

(i) such other particulars as may be prescribed.

(2) In respect of all establishments which come within the scope of the Act for the first time, the occupier shall send a written notice to the Chief Inspector containing the particulars specified in sub-section (1) within thirty days from the date of the commencement of this Act.

(3) Before a factory engaged in a manufacturing process which is ordinarily carried on for less than one hundred and eighty working days in the year resumes working, the occupier shall send a written notice to the Chief Inspector containing the particulars specified in sub-section (1) <sup>4</sup>[at least thirty days] before the date of the commencement of work.

(4) Whenever a new manager is appointed, the occupier shall send to the <sup>5</sup>[Inspector a written notice and to the Chief Inspector a copy thereof] within seven days from the date on which such person takes over charge.

(5) During any period for which no person has been designated as manager of a factory or during which the person designated does not manage the factory, any person found acting as manager, or if no such person is found, the occupier himself, shall be deemed to be the manager of the factory for the purposes of this Act.

## CHAPTER II

## THE INSPECTING STAFF

<sup>1</sup>[7A. General duties of the occupier.—(1) Every occupier shall ensure, so far as is reasonably practicable, the health, safety and welfare of all workers while they are at work in the factory.

(2) Without prejudice to the generality of the provisions of sub-section (1), the matters to which such duty extends, shall include—

(a) the provision and maintenance of plant and systems of work in the factory that are safe and without risks to health;

(b) the arrangements in the factory for ensuring safety and absence of risks to health in connection with the use, handling, storage and transport of articles and substances;

(c) the provisions of such information, instruction, training and supervision as are necessary to ensure the health and safety of all workers at work;

(d) the maintenance of all places of work in the factory in a condition that is safe and without risks to health and the provision and maintenance of such means of access to, and egress from, such places as are safe and without such risks;

(e) the provision, maintenance or monitoring of such working environment in the factory for the workers that is safe, without risks to health and adequate as regards facilities and arrangements for their welfare at work.

(3) Except in such cases as may be prescribed, every occupier shall prepare, and, as often as may be appropriate, revise, a written statement of his general policy with respect to the health and safety of the workers at work and the organisation and arrangements for the time being in force for carrying out that policy, and to bring the statement and any revision thereof to the notice of all the workers in such manner as may be prescribed.

\*7B. General duties of manufacturers, etc., as regards articles and substances for use in factories.—(1) Every person who designs, manufactures, imports or supplies any article for use in any factory, shall—

(a) ensure, so far as is reasonably practicable, that the article is so designed and constructed as to be safe and without risks to the health of the workers when properly used;

(b) carry out or arrange for the carrying out of such tests and examination as may be considered necessary for the effective implementation of the provisions of clause (a);

(c) take such steps as may be necessary to ensure that adequate information will be available—

(i) in connection with the use of the article in any factory;

(ii) about the use for which it is designed and tested; and

(iii) about any conditions necessary to ensure that the article, when put to such use, will be safe, and without risks to the health of the workers:

Provided that where an article is designed or manufactured outside India, it shall be obligatory on the part of the importer to see—

(a) that the article conforms to the same standards if such article is manufactured in India, or

(b) if the standards adopted in the country outside for the manufacture of such article is above the standards adopted in India, that the article conforms to such standards.

(2) Every person, who undertakes to design or manufacture any article for use in any factory, may carry out or arrange for the carrying out of necessary research with a view to the discovery and, so far as is reasonably practicable, the elimination or minimisation of any risks to the health or safety of the workers to which the design or article may give rise.

(3) Nothing contained in sub-sections (1) and (2) shall be construed to require a person to repeat the testing, examination or research which has been carried out otherwise than by him or at his instance in so far as it is reasonable for him to rely on the results thereof for the purposes of the said sub-sections.

(4) Any duty imposed on any person by sub-sections (1) and (2) shall extend only to things done in the course of business carried on by him and to matters within his control.

(5) Where a person designs, manufactures, imports or supplies an article on the basis of a written undertaking by the user of such article to take the steps specified in such undertaking to ensure, so far as is reasonably practicable, that the article will be safe and without risks to the health of the workers when properly used, the undertaking shall have the effect of relieving the person designing, manufacturing, importing or supplying the article from the duty imposed by clause (a) of sub-section (1) to such extent as is reasonable having regard to the terms of the undertaking.

(6) For the purposes of this section, an article is not to be regarded as properly used if it is used without regard to any information or advice relating to its use which has been made available by the person who has designed, manufactured, imported or supplied the article.

Explanation.—For the purposes of this section, “article” shall include plant and machinery.]

8. Inspectors.—(1) The State Government may, by notification in the Official Gazette, appoint such persons as possess the prescribed qualification to be Inspectors for the purposes of this Act and may assign to them such local limits as it may think fit.

(2) The State Government may, by notification in the Official Gazette, appoint any person to be a Chief Inspector who shall, in addition to the powers conferred on a Chief Inspector under this Act, exercise the powers of an Inspector throughout the State.

<sup>1</sup>[(2A) The State Government may, by notification in the Official Gazette, appoint as many Additional Chief Inspectors, Joint Chief Inspectors and Deputy Chief Inspectors and as many other officers as it thinks fit to assist the Chief Inspector and to exercise such of the powers of the Chief Inspector as may be specified in such notification.

(2B) Every Additional Chief Inspector, Joint Chief Inspector, Deputy Chief Inspector and every other officer appointed under sub-section (2A) shall, in addition to the powers of a Chief Inspector specified in the notification by which he is appointed, exercise the power of an Inspector throughout the State.]

(3) No person shall be appointed under sub-section (1), sub-section (2) <sup>1</sup>[, sub-section (2A)] or sub-section (5) or, having been so appointed, shall continue to hold office, who is or becomes directly or indirectly interested in a factory or in any process or business carried on therein or in any patent or machinery connected therewith.

(4) Every District Magistrate shall be an Inspector for his district.

(5) The State Government may also, by notification as aforesaid, appoint such public officers as it thinks fit to be additional Inspectors for all or any of the purposes of this Act, within such local limits as it may assign to them respectively.

(6) In any area where there are more Inspectors than one the State Government may, by notification as aforesaid, declare the powers, which such Inspectors shall respectively exercise and the Inspector to whom the prescribed notices are to be sent.

(7) <sup>2</sup>[Every Chief Inspector, Additional Chief Inspector, Joint Chief Inspector, Deputy Chief Inspector, Inspector and every other officer appointed under this section] shall be deemed to be a public servant within the meaning of the Indian Penal Code (45 of 1860), and shall be officially subordinate to such authority as the State Government may specify in this behalf.

9. Powers of Inspectors.—Subject to any rules made in this behalf, an Inspector may, within the local limits for which he is appointed,—

(a) enter, with such assistants, being persons in the service of the Government, or any local or other public authority, [or with an expert] as he thinks fit, any place which is used, or which he has reason to believe is used, as a factory;

<sup>2</sup>[(b) make examination of the premises, plant, machinery, article or substance;

(c) inquire into any accident or dangerous occurrence, whether resulting in bodily injury, disability or not, and take on the spot or otherwise statements of any person which he may consider necessary for such inquiry;

(d) require the production of any prescribed register or any other document relating to the factory;

(e) seize, or take copies of, any register, record or other document or any portion thereof, as he may consider necessary in respect of any offence under this Act, which he has reason to believe, has been committed;

(f) direct the occupier that any premises or any part thereof, or anything lying therein, shall be left undisturbed (whether generally or in particular respects) for so long as is necessary for the purpose of any examination under clause (b);

(g) take measurements and photographs and make such recordings as he considers necessary for the purpose of any examination under clause (b), taking with him any necessary instrument or equipment;

(h) in case of any article or substance found in any premises, being an article or substance which appears to him as having caused or is likely to cause danger to the health or safety of the workers, direct it to be dismantled or subject it to any process or test (but not so as to damage or destroy it unless the same is, in the circumstances necessary, for carrying out the purposes of this Act), and take possession of any such article or substance or a part thereof, and detain it for so long as is necessary for such examination;

(i) exercise such other powers as may be prescribed.]

10. Certifying surgeons.—(1) The State Government may appoint qualified medical practitioners to be certifying surgeons for the purposes of this Act within such local limits or for such factory or class or description of factories as it may assign to them respectively.

(2) A certifying surgeon may, with the approval of the State Government, authorise any qualified medical practitioner to exercise any of his powers under this Act for such period as the certifying surgeon may specify and subject to such conditions as the State Government may think fit to impose, and references in this Act to a certifying surgeon shall be deemed to include references to any qualified medical practitioner when so authorised.

(3) No person shall be appointed to be, or authorised to exercise the powers of, a certifying surgeon, or having been so appointed or authorised, continue to exercise such powers, who is or becomes the occupier of a factory or is or becomes directly or indirectly interested therein or in any process or business carried on therein on in any patent or machinery connected therewith or is otherwise in the employ of the factory:

<sup>3</sup>[Provided that the State Government may, by order in writing and subject to such conditions as may be specified in the order, exempt any person or class of persons from the provisions of this sub-section in respect of any factory or class or description of factories.]

(4) The certifying surgeon shall carry out such duties as may be prescribed in connection with—

(a) the examination and certification of young persons under this Act;

(b) the examination of persons engaged in factories in such dangerous occupations or processes as may be prescribed;

(c) the exercising of such medical supervision as may be prescribed for any factory or class or description of factories where—

(i) cases of illness have occurred which it is reasonable to believe are due to the nature of the manufacturing process carried on, or other conditions of work prevailing, therein;

(ii) by reason of any change in the manufacturing process carried on or in the substances used therein or by reason of the adoption of any new manufacturing process or of any new substance for use in a manufacturing process, there is a likelihood of injury to the health of workers employed in that manufacturing process;

(iii) young persons are, or are about to be, employed in any work which is likely to cause injury to their health.

Explanation.—In this section “qualified medical practitioner” means a person holding a qualification granted by an authority specified in the Schedule to the Indian Medical Degrees Act, 1916 (7 of 1916), or in the Schedules to the Indian Medical Council Act, 1933 (27 of 1933)<sup>1</sup>.

## CHAPTER III

## HEALTH

11. Cleanliness.—(1) Every factory shall be kept clean and free from effluvia arising from any drain, privy or other nuisance, and in particular—

(a) accumulation of dirt and refuse shall be removed daily by sweeping or by any other effective method from the floors and benches of workrooms and from staircases and passages, and disposed of in a suitable manner;

(b) the floor of every workroom shall be cleaned at least once in every week by washing, using disinfectant, where necessary, or by some other effective method;

(c) where a floor is liable to become wet in the course of any manufacturing process to such extent as is capable of being drained, effective means of drainage shall be provided and maintained;

(d) all inside walls and partitions, all ceilings or tops of rooms and all walls, sides and tops of passages and staircases shall—

(i) where they are <sup>2</sup>[painted otherwise than with washable water-paint] or varnished, be repainted or revarnished at least once in every period of five years;

<sup>3</sup>[(ia) where they are painted with washable water-paint, be repainted with at least one coat of such paint at least once in every period of three years and washed at least once in every period of six months;]

(ii) where they are painted or varnished or where they have smooth impervious surfaces, be cleaned at least once in every period of fourteen months by such method as may be prescribed;

(iii) in any other case, be kept whitewashed, or colourwashed, and the whitewashing or colourwashing shall be carried out at least once in every period of fourteen months;

<sup>3</sup>[(dd) all doors and window frames and other wooden or metallic framework and shutters shall be kept painted or varnished and the painting or varnishing shall be carried out at least once in every period of five years;]

(e) the dates on which the processes required by clause (d) are carried out shall be entered in the prescribed register.

(2) If, in view of the nature of the operations carried on <sup>1</sup>[in a factory or class or description of factories or any part of a factory or class or description of factories], it is not possible for the occupier to comply with all or any of the provisions of subsection (1), the State Government may by order exempt such factory or class or description of factories [or part] from any of the provisions of that sub-section and specify alternative methods for keeping the factory in a clean stale.

12. Disposal of wastes and effluents.—<sup>3</sup>[(1) Effective arrangements shall be made in every factory for the treatment of wastes and effluents due to the manufacturing process carried on therein, so as to render them innocuous, and for their disposal.]

(2) The State Government may make rules prescribing the arrangements to be made under sub-section (1) or requiring that the arrangements made in accordance with sub-section (1) shall be approved by such authority as may be prescribed.

13. Ventilation and temperature.—(1) Effective and suitable provision shall be made in ever factory for securing and maintaining in every workroom—

(a) adequate ventilation by the circulation of fresh air, and

(b) such a temperature as will secure to workers therein reasonable conditions of comfort and prevent injury to health;

and in particular,—

(i) walls and roofs shall be of such material and so designed that such temperature shall not be exceeded bill kept as tow as practicable;

(ii) where the nature of the work carried on in the factory involves, or is likely to involve the production of excessively high temperatures, such adequate measures as are practicable shall be taken to protect the workers therefrom, by separating the process which produces such temperatures from the workroom, by insulating the hot parts or by other effective means.

(2) The State Government may prescribe a standard of adequate ventilation and reasonable temperature for any factory or class or description of factories or parts thereof and direct that <sup>4</sup>[proper measuring instruments, at such places and in such position as may be specified, shall be provided and such records, as may be prescribed, shall be maintained.]

<sup>5</sup>[(3) If it appears to the Chief Inspector that excessively high temperatures in any factory can be reduced by the adoption of suitable measures, he may, without prejudice to the rules made under sub-section (2), serve on the occupier, an order in writing specifying the measures which, in his opinion, should be adopted, and requiring them to be carried out before a specified date.]

14. Dust and fume.—(1) In every factory in which, by reason of the manufacturing process carried on, there is given off any dust or fume or other impurity of such a nature and to such an extent as is likely to be injurious or offensive to the workers employed therein, or any dust in substantial quantities, effective measures shall be taken to prevent its inhalation and accumulation in any workroom, and if any exhaust appliance is necessary for this purpose, it shall be applied as near as possible to the point of origin of the dust, fume or other impurity, and such point shall be enclosed so far as possible.

(2) In any factory no stationary internal combustion engine shall be operated unless the exhaust is conducted into the open air, and no other internal combustion engine shall be operated in any room unless effective measures have been taken to prevent such accumulation of fumes therefrom as are likely to be injurious to workers employed in the room.

15. Artificial humidification.—(1) In respect of all factories in which the humidity of the air is artificially increased, the State Government may make rules,—

(a) prescribing standards of humidification;

(b) regulating the methods used for artificially increasing the humidity of the air;

(c) directing prescribed tests for determining the humidity of the air to be correctly carried out and recorded;

(d) prescribing methods to be adopted for securing adequate ventilation and cooling of the air in the workrooms.

(2) In any factory in which the humidity of the air is artificially increased, the water used for the purpose shall be taken from a public supply, or other source of drinking water, or shall be effectively purified before it is so used.

(3) If it appears to an Inspector that the water used in a factory for increasing humidity which is required to be effectively purified under sub-section (2) is not effectively purified he may serve on the manager of the factory an order in writing, specifying the measures which in his opinion should be adopted, and requiring them to be carried out before specified date.

16. Overcrowding.—(1) No room in any factory shall be overcrowded to an extent injurious to the health of the workers employed therein.

(2) Without prejudice to the generality of sub-section (1) there shall be in every workroom of a factory in existence on the date of the commencement of this Act at least [9.9 cubic metres] and of a factory built after the commencement of this Act at least <sup>2</sup>[14.2 cubic metres] of space for every worker employed therein, and for the purposes of this sub-section no account shall be taken of any space which is more than <sup>3</sup>[4.2 metres] above the level of the floor of the room.

(3) If the Chief Inspector by order in writing so requires, there shall be posted in each workroom of a factory a notice specifying the maximum number of workers who may, in compliance with the provisions of this section, be employed in the room.

(4) The Chief Inspector may by order in writing exempt, subject to such conditions, if any, as he may think fit to impose, any workroom from the provisions of this section, if he is satisfied that compliance therewith in respect of the room is unnecessary in the interest of the health of the workers employed therein.

17. Lighting.—(1) In every part of a factory where workers are working of passing there shall be provided and maintained sufficient and suitable lighting, natural or artificial, or both.

(2) In every factory all glazed windows and skylights used for the lighting of the workrooms shall be kept clean on both the inner and outer surfaces and, so far as compliance with the provisions of any rules made under sub-section (3) of section 13 will allow, free from obstruction.

(3) In every factory effective provision shall, so far as is practicable, be made for the prevention of—

(a) glare, either directly from a source of light or by reflection from a smooth or polished surface:

(b) the formation of shadows to such an extent as to cause eye-strain or the risk of accident to any worker.

(4) The State Government may prescribe standards of sufficient and suitable lighting for factories or for any class or description of factories or for any manufacturing process.

18. Drinking water.—(1) In every factory effective arrangements shall be made to provide and maintain at suitable points conveniently situated for all workers employed therein a sufficient supply of wholesome drinking water.

(2) All such points shall be legibly marked “drinking water” in a language understood by a majority of the workers employed in the factory, and no such point shall be situated within <sup>1</sup>[six metres of any washing place, urinal, latrine, spittoon, open drain carrying sullage or effluent or any other source of contamination] unless a shorter distance is approved in writing by the Chief Inspector.

(3) In every factory wherein more than two hundred and fifty workers are ordinarily employed, provision shall be made for cool drinking water during hot weather by effective means and for distribution thereof.

(4) In respect of all factories or any class or description of factories the State Government may make rules for securing compliance with the provisions of sub-sections (1), (2) and (3) and for the examination by prescribed authorities of the supply and distribution of drinking water in factories.

19. Latrines and urinals.—(1) In every factory—

(a) sufficient latrine and urinal accommodation of prescribed types shall be provided conveniently situated and accessible to workers at all times while they are at factory;

(b) separate enclosed accommodation shall be provided for male and female workers;

(c) such accommodation shall be adequately lighted and ventilated, and no latrine or urinal shall, unless specially exempted in writing by the Chief Inspector, communicate with any work room except through an intervening open space or ventilated passage;

(d) all such accommodation shall be maintained in a clean and sanitary condition at all times;

(e) sweepers shall be employed whose primary duty it would be to keep clean latrines, urinals and washing places.

(2) In every factory wherein more than two hundred and fifty workers are ordinarily employed—

(a) all latrine and urinal accommodation shall be of prescribed sanitary types;

(b) the floors and internal walls, up to a height of <sup>2</sup>[ninety centimetres], of the latrines and urinals and the sanitary blocks shall be laid in glazed tiles or otherwise finished to provide a smooth polished impervious surface;

(c) without prejudice to the provisions of clauses (d) and (e) of sub-section (1), the floors, portions of the walls and blocks so laid or finished and the sanitary pans of latrines and urinals shall be thoroughly washed and cleaned at least once in every seven days with suitable detergents or disinfectants or with both.

(3) The State Government may prescribe the number of latrines and urinals to be provided in any factory in proportion to the numbers of male and female workers ordinarily employed therein, and provide for such further mailers in respect of sanitation in factories, including the obligation of workers in this regard, as it considers necessary in the interest of the health of the workers employed therein.

20. Spittoons.—(1) In every factory there shall be provided a sufficient number of spittoons in convenient places and they shall be maintained in a clean and hygienic condition.

(2) The State Government may make rules prescribing the type and the number of spittoons to be provided and their location in any factory and provide for such further matters relating to their maintenance in a clean and hygienic condition.

(3) No person shall spit within the premises of a factory except in the spittoons provided for the purpose and a notice containing this provision and the penalty for its violation shall be prominently displayed at suitable places in the premises.

(4) Whoever spits in contravention of sub-section (3) shall be punishable with fine not exceeding five rupees.

## CHAPTER IV

## SAFETY

## 21. Fencing of machinery.—(1) In every factory the following, namely:—

(i) every moving part of a prime mover and every flywheel connected to a prime mover, whether the prime mover or flywheel is in the engine house or not;

(ii) the headrace and tailrace of every water-wheel and water turbine:

(iii) any part of a stock-bar which projects beyond the head stock of a lathe; and

(iv) unless they are in such position or of such construction as to be safe to every person employed in the factory as they would be if they were securely fenced, the following, namely:—

(a) every part of an electric generator, a motor or rotary converter;

(b) every part of transmission machinery; and

(c) every dangerous part of any other machinery;

shall be securely fenced by safeguards of substantial construction which <sup>1</sup>[shall be constantly maintained and kept in position] while the parts of machinery the y are fencing are in motion or in use:

<sup>2</sup>[Provided that for the purpose of determining whether any part of machinery is in such position or is of such construction as to be safe as aforesaid, account shall not be taken of any occasion when—

(i) it is necessary to make an examination of any part of the machinery aforesaid while it is in motion or, a s a result of such examination, to carry out lubrication or other adjusting operation while the machinery is in motion, being an examination or operation which it is necessary to be carried out while that part of the machinery is in motion, or

(ii) in the case of any part of a transmission machinery used in such process as may be prescribed (being a process of a continuous nature the carrying on of which shall be, or is likely to be, substantially interfered with by the stoppage of that part of the machinery), it is necessary to make an examination of such part of the machinery while it is in motion or, as a result of such examination, to carry out any mounting or shipping of belts or lubrication or other adjusting operation while the machinery is in motion,

and such examination or operation is made or carried out in accordance with the provisions of sub-section (1) of section 22.]

(2) The State Government may by rules prescribe such further precautions as it may consider necessary in respect of any particular machinery or part thereof, or exempt, subject to such condition as may be prescribed, for securing the safety of the workers, any particular machinery or part thereof from the provisions of this section.

22. Work on or near machinery in motion.—(1) <sup>3</sup>[Where in any factory it becomes necessary to examine any part of machinery referred to in section 21, while the machinery is in motion, or, as a result of such examination, to carry out—

(a) in a case referred to in clause (i) of the proviso to sub-section (1) of section 21, lubrication or other adjusting operation; or

(b) in a case referred to in clause (ii) of the proviso aforesaid, any mounting or shipping of belts or lubrication or other adjusting operation,

while the machinery is in motion, such examination or operation shall be made or carried out only by a specially trained adult male worker wearing tight fitting clothing (which shall be supplied by the occupier) whose name has been recorded in the register prescribed in this behalf and who has been furnished with a certificate of this appointment, and while he is so engaged,—

(a) such worker shall not handle a belt at a moving pulley unless—

(i) the belt is not more than fifteen centimetres in width;

(ii) the pulley is normally for the purpose of drive and not merely a fly-wheel or balance wheel (in which case a belt is not permissible);

(iii) the belt joint is either laced or flush with the belt;

(iv) the belt, including the joint and the pulley rim, are in good repair;

(v) there is reasonable clearance between the pulley and any fixed plant or structure;

(vi) secure foothold and, where necessary, secure handhold, are provided for the operator; and

(vii) any ladder in use for carrying out any examination or operation aforesaid is securely fixed or lashed or is firmly held by a second person;]

(b) without prejudice to any other provision of this Act relating to the fencing of machinery, every set screw, bolt and key on any revolving shaft, spindle, wheel or pinion, and all spur, worm and other toothed or friction gearing in motion with which such worker would otherwise be liable to come into contact, shall be securely fenced to prevent such contact.

<sup>1</sup>[(2) No woman or young person shall be allowed to clean, lubricate or adjust any part of a prime mover or of any transmission machinery while the prime mover or transmission machinery is in motion, or to clean, lubricate or adjust any part of any machine if the cleaning, lubrication or adjustment thereof would expose the woman or young person to risk of injury from any moving part either of that machine or of any adjacent machinery.]

(3) The State Government may, by notification in the Official Gazette, prohibit, in any specified factory or class or description of factories, the cleaning, lubricating or adjusting by any person of specified parts of machinery when those parts are in motion.

23. Employment of young persons on dangerous machines.—(1) No young person <sup>2</sup>[shall be required or allowed to work] at any machine to which this section applies, unless he has been fully instructed as to the dangers arising in connection with the machine and the precautions to be observed and—

(a) has received sufficient training in work at the machine, or

(b) is under adequate supervision by a person who has a thorough knowledge and experience of the machine.

(2) Sub-section (1) shall apply to such machines as may be prescribed by the State Government, being machines which in its opinion are of such a dangerous character that young persons ought not to work at them unless the foregoing requirements are complied with.

24. Striking gear and devices for cutting off power.—(1) In every factory—

(a) suitable striking gear or other efficient mechanical appliance shall be provided and maintained and used to move driving belts to and from fast and loose pulleys which form part of the transmission machinery, and such gear or appliances shall be so constructed, placed and maintained as to prevent the belt from creeping back on the fast pulley;

(b) driving belts when not in use shall not be allowed to rest or ride upon shafting in motion.

(2) In every factory suitable devices for cutting off power in emergencies from running machinery shall be provided and maintained in every workroom:

Provided that in respect of factories in operation before the commencement of this Act, the provisions of this sub-section shall apply only to workrooms in which electricity is used as power.

<sup>1</sup>[(3) When a device, which can inadvertently shift from “off” to “on” position, is provided in a factory to cut off power, arrangements shall be provided for locking the device in safe position to prevent accidental starting of the transmission machinery or other machines to which the device is fitted].

25. Self-acting machines.—No traversing part of a self-acting machine in any factory and no material carried thereon shall, if the space over which it runs is a space over which any person is liable to pass, whether in the course of his employment or otherwise, be allowed to run on its outward or inward traverse within a distance of <sup>2</sup>[forty-five centimetres] from any fixed structure which is not part of the machine:

Provided that the Chief Inspector may permit the continued use of a machine installed before the commencement of this Act which does not comply with the requirements of this section on such conditions for ensuring safety as he may think fit to impose.

26. Casing of new machinery.—(1) In all machinery driven by power and installed in any factory after the commencement of this Act,—

(a) every set screw, bolt or key on any revolving shaft, spindle, wheel or pinion shall be so sunk, encased or otherwise effectively guarded as to prevent danger;

(b) all spur, worm and other toothed or friction gearing which does not require frequent adjustment while in motion shall be completely encased, unless it is so situated as to be as safe as it would be if it were completely encased.

(2) Whoever sells or lets on hire or, as agent of a seller or hirer, causes or procures to be sold or let on hire, for use in a factory any machinery driven by power which does not comply with the provisions of <sup>3</sup>[sub-section (1) or any rules made under sub-section (3)], shall be punishable with imprisonment for a term which may extend to three months or with fine which may extend to five hundred rupees or with both.

<sup>4</sup>[(3) The State Government may make rules specifying further safeguards to be provided in respect of any other dangerous part of any particular machine or class or description of machines.]

27. Prohibition of employment of women and children near cotton-openers.—No woman or child shall be employed in any part of a factory for pressing cotton in which a cotton opener is at work:

Provided that if the feed-end of a cotton-opener is in a room separated from the delivery end by a partition extending to the roof or to such height as the Inspector may in any particular case specify in writing, women and children may be employed on the side of the partition where the feed-end is situated.

28. Hoists and lifts.—(1) In every factory—

(a) every hoist and lift shall be—

(i) of good mechanical construction, sound material and adequate strength;

(ii) properly maintained, and shall be thoroughly examined by a competent person at least once in every period of six months, and a register shall be kept containing the prescribed particulars of very such examination;

(b) every hoist way and lift way shall be sufficiently protected by an enclosure fitted with gates, and the hoist or lift and every such enclosure shall be so constructed as to prevent any person or thing from being trapped between any part of the hoist or lift and any fixed structure or moving part;

(c) the maximum safe working load shall be plainly marked on every hoist or lift, and no load greater than such load shall be carried thereon;

(d) the cage of every hoist or lift used for carrying persons shall be fitted with a gate on each side from which access is afforded to a landing;

(e) every gate referred to in clause (b) or clause (d) shall be fitted with interlocking or other efficient device to secure that the gate cannot be opened except when the cage is at the landing and that the cage cannot be moved unless the gate is closed.

(2) The following additional requirement shall apply to hoists and lifts used for carrying persons and installed or reconstructed in a factory after the commencement of this Act, namely:—

(a) where the cage is supported by rope or chain, there shall be at least two ropes of chains separately connected with the cage and balance weight, and each rope or chain with its attachments shall be capable of carrying the whole weight of the cage together with its maximum load;

(b) efficient devices shall be provided and maintained capable of supporting the cage together with its maximum load in the event of breakage of the ropes, chains or attachments;

(c) an efficient automatic device shall be provided and maintained to prevent the cage from over-running.

(3) The Chief Inspector may permit the continued, use of a hoist of lift installed in a factory before the commencement of this Act which does not fully comply with the provisions of sub-section (1) upon such conditions for ensuring safely as he may think fit to impose.

(4) The State Government may, if in respect of any class or description of hoist or lift, it is of opinion that it would be unreasonable to enforce any requirement of sub-sections (1) and (2), by order direct that such requirement shall not apply to such class or description of hoist or lift.

<sup>1</sup>[Explanation.—For the purposes of this section, no lifting machine or appliance shall be deemed to be a hoist or lift unless it has a platform or cage, the direction or movement of which is restricted by a guide or guides.]

<sup>2</sup>[29. Lifting machines, chains, ropes and lifting tackles.—(1) In any factory the following provisions shall be complied with in respect of every lifting machine (other than a hoist and lift) and every chain, rope and lifting tackle for the purpose of raising or lowering persons, goods or materials:—

(a) all parts, including the working gear, whether fixed or movable, of every lifting machine and every chain, rope or lifting tackle shall be—

(i) of good construction, sound material and adequate strength and free from defects;

(ii) properly maintained; and

(iii) thoroughly examined by a competent person at least once in every period of twelve months, or at such intervals as the Chief Inspector may specify in writing; and a register shall be kept containing the prescribed particulars of every such examination;

(b) no lifting machine and no chain, rope or lifting tackle shall, except for the purpose of test be loaded beyond the safe working load which shall be plainly marked thereon together with an identification mark and duly entered in the prescribed register; and where this is not practicable, a table showing the safe working loads of every kind and size of lifting machine or chain, rope or lifting tackle in use shall be displayed in prominent positions on the premises;

(c) while any person is employed or working on or near the wheel track of a travelling crane in any place where he would be liable to be struck by the crane, effective measures shall be taken to ensure that the crane does not approach within <sup>1</sup>[six metres] of that place.

(2) The State Government may make rules in respect of any lifting machine or any chain, rope or lifting tackle used in factories—

(a) prescribing further requirements to be complied with in addition to those set out in this section;

(b) providing for exemption from compliance with all or any of the requirements of this section, where in its opinion, such compliance is unnecessary or impracticable.

(3) For the purposes of this section a lifting machine or a chain, rope or lifting tackle shall be deemed to have been thoroughly examined if a visual examination supplemented, if necessary, by other means and by the dismantling of parts of the gear, has been carried out as carefully as the conditions permit in order to arrive at a reliable conclusion as to the safely of the parts examined.

Explanation.—In this section.—

(a) “lifting machine” means a crane, crab, winch, teagle, pulley block, gin wheel, transporter or runway;

<sup>2</sup>[(b) “lifting tackle” means any chain sling, rope sling, hook, shackle, swivel, coupling, socket, clamp, tray or similar appliance, whether fixed or movable, used in connection with the raising or lowering of persons, or loads by use of lifting machines.]

30. Revolving machinery.—(1) <sup>3</sup>[In every factory] in which the process of grinding is carried on there shall be permanently affixed to or placed near each machine in use a notice indicating the maximum safe working peripheral speed of every grindstone or abrasive wheel, the speed of the shaft or spindle upon which the wheel is mounted, and the diameter of the pulley upon such shaft or spindle necessary to secure such safe working peripheral speed.

(2) The speeds indicated in notices under sub-section (1) shall not be exceeded.

(3) Effective measures shall be taken in every factory to ensure that the safe working peripheral speed of every revolving vessel, cage, basket, fly-wheel, pulley, disc or similar appliance driven by power is not exceeded.

31. Pressure plant.—<sup>4</sup>[(1) If in any factory, any plant or machinery or any part thereof is operated at a pressure above atmospheric pressure, effective measures shall be taken to ensure that the safe working pressure of such plant or machinery or part is not exceeded.]

(2) The State Government may make rules providing for the examination and testing of any plant or machinery such as is referred to in sub-section (1) and prescribing such other safety measures in relation thereto as may in its opinion be necessary in any factory or class or description of factories.

<sup>5</sup>[(3) The State Government may, by rules, exempt, subject to such conditions as may be specified therein, any part of any plant or machinery referred to in sub-section (1) from the provisions of this section.]

32. Floors, stairs and means of access.—In every factory—

(a) all floors, steps, stairs, passages and gangways shall be of sound construction and properly maintained <sup>6</sup>[and shall be kept free from obstructions and substances likely to cause persons to slip], and where it is necessary to ensure safety, steps, stairs, passages and gangways shall be provided with substantial handrails;

(b) there shall, so far as is reasonably practicable, be provided and maintained safe means of access to every place at which any person is at any time required to work.

<sup>1</sup>[(c) when any person has to work at a height from where he is likely to fall, provision shall be made, so far as is reasonably practicable, by fencing or otherwise, to ensure the safety of the person so working.]

33. Pits, sumps openings in floors, etc.—(1) In every factory every fixed vessel, sump, tank, pit or opening in the ground or in a floor which, by reason of its depth, situation, construction or contents, is or may be a source of danger, shall be either securely covered or securely fenced.

(2) The State Government may, by order in writing, exempt, subject to such conditions as may be prescribed, any factory or class or description of factories in respect of any vessel, sump, tank, pit or opening from compliance with the provisions of this section.

34. Excessive weights.—(1) No person shall be employed in any factory to lift, carry or move any load so heavy as to be likely to cause him injury.

(2) The State Government may make rules prescribing the maximum weights which may be lifted, carried or moved by adult men, adult women, adolescents and children employed in factories or in any class or description of factories or in carrying or any specified process.

35. Protection of eyes.—In respect of any such manufacturing process carried on in any factory as may be prescribed, being a process which involves—

(a) risk of injury to the eyes from particles or fragments thrown off in the course of the process, or

(b) risk to the eyes by reason of exposure to excessive light, the State Government may by rules require that effective screens or suitable goggles shall be provided for the protection of persons employed on, or in the immediate vicinity of, the process.

<sup>2</sup>[36. Precautions against dangerous fumes, gases, etc.—(1) No person shall be required or allowed to enter any chamber, tank, vat, pit, pipe, flue or other confined space in any factory in which any gas, fume vapour or dust is likely to be present to such an extent as to involve risk to persons being overcome thereby, unless it is provided with a manhole of adequate size or other effective means of egress.

(2) No person shall be required or allowed to enter any confined space as is referred to in sub-section (1), until all practicable measures have been taken to remove any gas, fume, vapour or dust, which may be present so as to bring its level within the permissible limits and to prevent any ingress of such gas, fume, vapour or dust and unless—

(a) a certificate in writing has been given by a competent person, based on a test carried out by himself that the space is reasonably free from dangerous gas, fume, vapour or dust; or

(b) such person is wearing suitable breathing apparatus and a belt securely attached to a rope the free end of which is held by a person outside the confined space.]

<sup>3</sup>[36A. Precautions regarding the use of portable electric light.—In any factory—

(a) no portable electric light or any other electric appliance of voltage exceeding twenty-four volts shall be permitted for use inside any chamber, tank, vat, pit, pipe, flue or other confined space [unless adequate safety devices are provided]; and

(b) if any inflammable gas, fume or dust is likely to be present in such chamber, tank, vat, pit, pipe, flue or other confined space, no lamp or light other than that flame-proof construction shall be permitted to be used therein.]

37. Explosive or inflammable dust, gas, etc.—(1) Where in any factory any manufacturing process produces dust, gas, fume or vapour of such character and to such extent as to be likely to explode on ignition, all practicable measure shall be taken to prevent any such explosion by—

(a) effective enclosure of the plant or machinery used in the process;

(b) removal or prevention of the accumulation of such dust, gas, fume or vapour;

(c) exclusion or effective enclosure of all possible sources of ignition.

(2) Where in any factory the plant or machinery used in a process such as is referred to in sub-section (1) is not so constructed as to withstand the probable pressure which such an explosion as aforesaid would produce, all practicable measures shall be taken to restrict the spread and effects of the explosion by the provision in the plant or machinery of chokes, baffles, vents or other effective appliances.

(3) Where any part of the plant or machinery in a factory contains any explosive or inflammable gas or vapour under pressure greater than atmospheric pressure, that part shall not be opened except in accordance with the following provisions, namely:—

(a) before the fastening of any joint of any pipe connected with the part or the fastening of the cover of any opening into the part is loosened, any flow of the gas or vapour into the part of any such pipe shall be effectively stopped by a stop-valve or other means;

(b) before any such fastening as aforesaid is removed, all practicable measures shall be taken to reduce the pressure of the gas or vapour in the part or pipe to atmospheric pressure;

(c) where any such fastening as aforesaid has been loosened or removed effective measures shall be taken or prevent any explosive or inflammable gas or vapour from entering the part or pipe until the fastening has been secured, or the case may be, securely replaced;

Provided that the provisions of this sub-section shall not apply in the case of plant or machinery installed in the open air.

(4) No plant, tank or vessel which contains or has contained any explosive or inflammable substance shall be subjected in any factory to any welding, brazing, soldering or cutting operation which involves the application of heat unless adequate measures have first been taken to remove such substance and any fumes arising therefrom or to render such substance and fumes non-explosive or non-inflammable, and no such substance shall be allowed to enter such plant, tank or vessel after any such operation until the metal has cooled sufficiently to prevent any risk of igniting the substance.

(5) The State Government may by rules exempt, subject to such conditions as may be prescribed, any factory or class or description of factories from compliance with all or any of the provisions of this section.

<sup>1</sup>[38. Precautions in case of fire.—(1) In every factory, all practicable measures shall he taken to prevent outbreak of fire and its spread, both internally and externally, and to provide and maintain—

(a) safe means of escape for all persons in the event of a fire, and

(b) the necessary equipment and facilities for extinguishing fire.

(2) Effective measures shall be taken to ensure that in every factory all the workers are familiar with the means of escape in case of fire and have been adequately trained in the routine to be followed in such cases.

(3) The State Government may make rules, in respect of any factory or class or description of factories, requiring the measures to be adopted to give effect to the provisions of sub-sections (1) and (2).

(4) Notwithstanding anything contained in clause (a) of sub-section (1) or sub-section (2), if the Chief Inspector, having regard to the nature of the work carried on in any factory, the construction of such factory, special risk to life or safety, or any other circumstances, is of the opinion that the measures provided in the factory, whether as prescribed or not, for the purposes of clause (a) of sub-section (1) or sub-section (2), are inadequate, he may, by order in writing, require that such additional measures as he may consider reasonable and necessary, be provided in the factory before such date as is specified in the order.]

39. Power to require specifications of defective parts or tests of stability.—If it appears to the Inspector that any building or part of a building or any part of the ways, machinery or plant in a factory is in such a condition that it may be dangerous to human life or safety, he may serve on [the occupier or manger or both] of the factory an order in writing requiring him before a specified date—

(a) to furnish such drawings, specifications and other particulars as may be necessary to determine whether such building, ways, machinery or plant can be used with safety, or

(b) to carry out such tests in such manner as may be specified in the order, and to inform the Inspector of the results thereof.

40. Safety of buildings and machinery.—(1) If it appears to the Inspector that any building or part of a building or any part of the ways, machinery or plant in a factory is in such a condition that it is dangerous to human life or safety, he may serve on <sup>1</sup>[the occupier or manager or both] of the factory an order in writing specifying the measures which in his opinion should be adopted, and requiring them to be carried out before a specified date.

(2) If it appears to the Inspector that the use of any building or part of a building or any part of the ways, machinery or plant in a factory involves imminent danger to human life or safety, he may serve on <sup>1</sup>[the occupier or manager or both] of the factory an order in writing prohibiting its use until it has been properly repaired or altered.

<sup>2</sup>[40A. Maintenance of buildings.—If it appears to the Inspector that any building or part of a building in a factory is in such a state of disrepair as is likely to lead to conditions detrimental to the health and welfare of the workers, he may serve on the occupier or manager or both of the factory an order in writing specifying the measures which in his opinion should be taken and requiring the same to be carried out before such date as is specified in the order.]

40B. Safety Officers.—(1) In every factory—

(i) wherein one thousand or more workers are ordinarily employed, or

(ii) wherein, in the opinion of the State Government, any manufacturing process or operation is carried on, which process or operation involves any risk of bodily injury, poisoning or disease, or any other hazard to health, to the persons employed in the factory,

the occupier shall, if so, required by the State Government by notification in the Official Gazette, employ such number of Safety Officers as may be specified in that notification.

(2) The duties, qualifications and conditions of service of Safety Officers shall be such as may be prescribed by the State Government.]

41. Power to make rules to supplement this Chapter.—The State Government may make rules requiring the provision in any factory or in any class or description of factories of such further <sup>3</sup>[devices and measures] for securing the safety of persons employed therein as it may deem necessary.

## <sup>1</sup>[CHAPTER IVA PROVISIONS RELATING TO HAZARDOUS PROCESSES

41A. Constitution of Site Appraisal Committee.—(1) The State Government may, for purposes of advising it to consider applications for grant of permission for the initial location of a factory involving a hazardous process or for the expansion of an such factory, appoint a Site Appraisal Committee consisting of—

(a) the Chief Inspector of the State who shall be its Chairman;

(b) a representative of the Central Board for the Prevention and Control of Water Pollution appointed by the Central Government under section 3 of the Water (Prevention and Control of Pollution) Act, 1974 (6 of 1974);

(c) a representative of the Central Board for the Prevention and Control of Air Pollution referred to in section 3 of the Air (Prevention and Control of Pollution) Act, 1981 (14 of 1981);

(d) a representative of the State Board appointed under section 4 of the Water (Prevention and Control of Pollution) Act, 1974 (6 of 1974);

(e) a representative of the State Board for the Prevention and Control of Air Pollution referred to in section 5 of the Air (Prevention and Control of Pollution) Act, 1981 (14 of 1981);

(f) a representative of the Department of Environment in the State;

(g) a representative of the Meteorological Department of the Government of India;

(h) an expert in the field of occupational health; and

(i) a representative of the Town Planning Department of the State Government,

and not more than five other members who may be co-opted by the State Government who shall be—

(i) a scientist having specialised knowledge of the hazardous process which will be involved in the factory,

(ii) a representative of the local authority within whose jurisdiction the factory is to be established, and

(iii) not more than three other persons as deemed fit by the State Government.

(2) The Site Appraisal Committee shall examine an application for the establishment of a factory involving hazardous process and make its recommendation to the State Government within a period of ninety days of the receipt of such application in the prescribed form.

(3) Where any process relates to a factory owned or controlled by the Central Government or to a corporation or a company owned or controlled by the Central Government, the State Government shall co-opt in the Site Appraisal Committee a representative nominated by the Central Government as a member of that Committee.

(4) The Site Appraisal Committee shall have power to call for any information from the person making an application for the establishment or expansion of a factory involving a hazardous process.

(5) Where the State Government has granted approval to an application for the establishment or expansion of a factory involving a hazardous process, it shall not be necessary for an applicant to obtain a further approval from the Central Board or the State Board established under the Water (Prevention and Control of Pollution) Act, 1974 (6 of 1974) and the Air (Prevention and Control of Pollution) Act, 1981 (14 of 1981).

41B. Compulsory disclosure of information by the occupier.—(1) The occupier of every factory involving a hazardous process shall disclose in the manner prescribed all information regarding dangers, including health hazards and the measures to overcome such hazards arising from the exposure to or handling of the materials or substances in the manufactures, transportation, storage and other processes, to the workers employed in the factory, the Chief Inspector, the local authority within whose jurisdiction the factory is situate and the general public in the vicinity.

(2) The occupier shall, at the time of registering the factory involving a hazardous process, lay down a detailed policy with respect to the health and safety of the workers employed therein and intimate such policy to the Chief Inspector and the local authority and, thereafter, at such intervals as may be prescribed, inform the Chief Inspector and the local authority of any change made in the said policy.

(3) The information furnished under sub-section (1) shall include accurate information as to the quantity, specification and other characteristics of wastes and the manner of their disposal.

(4) Every occupier shall, with the approval of the Chief Inspector, draw up an on-site emergency plan and detailed disaster control measures for his factory and make known to the workers employed therein and to the general public living in the vicinity of the factory the safety measures required to be taken in the event of an accident taking place.

(5) Every occupier of a factory shall,—

(a) if such factory engaged in a hazardous process on the commencement of the Factories (Amendment) Act, 1987 (20 of 1987), within a period of thirty days of such commencement; and

(b) if such factory proposes to engaged in a hazardous process at any time after such commencement, within a period of thirty days before the commencement of such process,

inform the Chief Inspector of the nature and details of the process in such form and in such manner as may be prescribed.

(6) Where any occupier of a factory contravenes the provisions of sub-section (5), the licence issued under section 6 to such factory shall, notwithstanding any penalty to which the occupier or factory shall be subjected to under the provisions of this Act, be liable for cancellation.

(7) The occupier of a factory involving a hazardous process shall, with the previous approval of the Chief Inspector, lay down measures for the handling, usage, transportation and storage of hazardous substances inside the factory premises and the disposal of such substances outside the factory premises and publicise them in the manner prescribed among the workers and the general public living in the vicinity.

41C. Specific responsibility of the occupier in relation to hazardous processes.—Every occupier of a factory involving any hazardous process shall—

(a) maintain accurate and up-to-date health records or, as the case may be, medical records, of the workers in the factory who are exposed to any chemical, toxic or any other harmful substances which are manufactured, stored, handled or transported and such records shall be accessible to the workers subject to such conditions as may be prescribed;

(b) appoint persons who possess qualifications and experience in handling hazardous substances and are competent to supervise such handling within the factory and to provide at the working place all the necessary facilities for protecting the workers in the manner prescribed:

Provided that where any question arises as to the qualifications and experience of a person so appointed, the decision of the Chief Inspector shall be final;

(c) provide for medical examination of every worker—

(a) before such worker is assigned to a job involving the handling of, or working with, a hazardous substance, and

(b) while continuing in such job, and after he has ceased to work in such job, at intervals not exceeding twelve months, in such manner as may be prescribed.

41D. Power of Central Government to appoint Inquiry Committee.—(1) The Central Government may, in the event of the occurrence of an extraordinary situation involving a factory engaged in a hazardous process, appoint an Inquiry Committee to inquire into the standards of health and safety observed in the factory with a view to finding out the causes of any failure or neglect in the adoption of any measures or standards prescribed for the health and safety of the workers employed in the factory or the general public affected, or likely to be affected, due to such failure or neglect and for the prevention and recurrence of such extraordinary situations in future in such factory or elsewhere.

(2) The Committee appointed under sub-section (1) shall consist of a Chairman and two other members and the terms of reference of the Committee and the tenure of office of its members shall be such as may be determined by the Central Government according to the requirements of the situation.

(3) The recommendations of the Committee shall be advisory in nature.

41E. Emergency standards.—(1) Where the Central Government is satisfied that no standards of safety have been prescribed in respect of a hazardous process or class of hazardous processes, or where the standards so prescribed are inadequate, it may direct the Director-General of Factory Advice Service and Labour Institutes or any institution specialised in matters relating to standards of safety in hazardous processes, to lay down emergency standards for enforcement of suitable standards in respect of such hazardous processes.

(2) The emergency standards laid down under sub-section (1) shall, until they are incorporated in the rules made under this Act, be enforceable and have the same effect as if they had been incorporated in the rules made under this Act.

\*41F. Permissible limits of exposure of chemical and toxic substances.—(1) The maximum permissible threshold limits of exposure of chemical and toxic substances in manufacturing processes (whether hazardous or otherwise) in any factory shall be of the value indicated in the Second Schedule.

(2) The Central Government may, at any time, for the purpose of giving effect to any scientific proof obtained from specialised institutions or experts in the field by notification in the Official Gazette, make suitable changes in the said Schedule.

41G. Workers’ participation in safety management.—(1) The occupier shall, in every factory where a hazardous process takes place, or where hazardous substances are used or handled, set up a Safety Committee consisting of equal number of representatives of workers and management to promote co-operation between the workers and the management in maintaining proper safety and health at work and to review periodical the measures taken in that behalf:

Provided that the State Government may, by order in writing and for reasons to be recorded exempt the occupier of any factory or class of factories from setting up such Committee.

(2) The composition of the Safety Committee, the tenure of office of its members and their rights and duties shall be such as may be prescribed.

41H. Right of workers to warn about imminent danger.—(1) Where the workers employed in any factory engaged in a hazardous process have reasonable apprehension that there is a likelihood of imminent danger to their lives or health due to any accident, they may bring the same to the notice of the occupier, agent, manager or any other person who is in charge of the factory or the process concerned directly or through their representatives in the Safety Committee and simultaneously bring the same to the notice of the Inspector.

(2) It shall be the duty of such occupier, agent, manager or the person in charge of the factory or process to take immediate remedial action if he is satisfied about the existence of such imminent danger and send a report forthwith of the action taken to the nearest Inspector.

(3) If the occupier, agent, manager or the person in charge referred to in sub-section (2) is not satisfied about the existence of any imminent danger as apprehended by the workers, he shall, nevertheless, refer the matter forthwith to the nearest Inspector whose decision on the question of the existence of such imminent danger shall be final.]

## CHAPTER V

## WELFARE

42. Washing facilities.—(1) In every factory—

(a) adequate and suitable facilities for washing shall be provided and maintained for the use of the workers therein;

(b) separate and adequately screened facilities shall be provided for the use of male and female workers;

(c) such facilities shall be conveniently accessible and shall be kept clean.

(2) The State Government may, in respect of any factory or class or description of factories or of any manufacturing process, prescribe standards of adequate and suitable facilities for washing.

43. Facilities for storing and drying clothing.—The State Government may, in respect of any factory or class or description of factories, make rules requiring the provision therein of suitable places for keeping clothing not worn daring working hours and for the drying of wet clothing.

44. Facilities for sitting.—(1) In every factory suitable arrangements for sitting shall be provided and maintained for all workers obliged to work in a standing position, in order that they may take advantage of any opportunities for rest which may occur in the course of their work.

(2) If, in the opinion of the Chief Inspector, the workers in any factory engaged in a particular manufacturing process or working in a particular room are able to do their work efficiently in a sitting position, he may, by order in writing, require the occupier of the factory to provide before a specified date such seating arrangements as may be practicable for all workers so engaged or working.

(3) The State Government may, by notification in the Official Gazette, declare that the provisions of sub-section (1) shall not apply to any specified factory or class or description of factories or to any specified manufacturing process.

45. First-aid appliances.—(1) There shall in every factory be provided and maintained so as to be readily accessible during all working hours first-aid boxes or cupboards equipped with the prescribed contents, and the number of such boxes or cupboards to be provided and maintained shall not be less than one for every one hundred and fifty workers ordinarily employed [at any one time] in the factory.

<sup>2</sup>[(2) Nothing except the prescribed contents shall be kept in a first-aid box or cupboard.

(3) Each first-aid box or cupboard shall be kept in the charge of a separate responsible person <sup>3</sup>[who holds a certificate in first-aid treatment recognised by the State Government] and who shall always be readily available during the working hours of the factory.]

<sup>4</sup>[(4)] In every factory wherein more than five hundred workers are <sup>5</sup>[ordinarily employed] there shall be provided and maintained an ambulance room of the prescribed size, containing the prescribed equipment and in the charge of such medical and nursing staff as may be prescribed <sup>6</sup>[and those facilities shall always be made readily available during the working hours of the factory].

46. Canteens.—(1) The State Government may make rules requiring that in any specified factory wherein more than two hundred and fifty workers are ordinarily employed, a canteen or canteens shall be provided and maintained by the occupier for the use of the workers.]

(2) Without prejudice to the generality of the foregoing power, such rules may provide for—

(a) the date by which such canteen shall be provided;

(b) the standards in respect of construction, accommodation, furniture and other equipment of the canteen;

(c) the foodstuffs to be served therein and the charges which may be made therefor;

(d) the constitution of a managing committee for the canteen and representation of the workers in the management of the canteen;

<sup>1</sup>[(dd) the items of expenditure in the running of the canteen which are not to be taken into account in fixing the cost of foodstuffs and which shall be borne by the employer;]

(e) the delegation to the Chief Inspector, subject to such conditions as may be prescribed, of the power to make rules under clause (c).

47. Shelters, rest rooms and lunch rooms.—(1) In every factory wherein more than one hundred and fifty workers are ordinarily employed, adequate and suitable shelters or rest rooms and a suitable lunch room, with provision for drinking water, where workers can eat meals brought by them, shall be provided and maintained for the use of the workers:

Provided that any canteen maintained in accordance with the provisions of section 46 shall be regarded as part of the requirements of this sub-section:

Provided further that where a lunch room exists no worker shall eat any food in the work room.

(2) The shelters or rest rooms or lunch rooms to be provided under sub-section (1) shall be sufficiently lighted aid ventilated and shall be maintained in a cool and clean condition.

(3) The State Government may—

(a) prescribe the standards in respect of construction, accommodation, furniture and other equipment of shelters, rest rooms and lunch rooms to be provided under this section;

(b) by notification in the Official Gazette, exempt any factory or class or description of factories from the requirements of this section.

48. Creches.—(1) In every factory wherein more than <sup>2</sup>[thirty women workers] are ordinarily employed there shall be provided and maintained a suitable room or rooms for the use of children under the age of six years of such women.

(2) Such rooms shall provide adequate accommodation, shall be adequately lighted and ventilated, shall be maintained in a clean and sanitary condition and shall be under the charge of women trained in the care of children and infants.

(3) The State Government may make rules—

(a) prescribing the location and the standards in respect of construction, accommodation, furniture and other equipment of rooms to be provided under this section;

(b) requiring the provision in factories to which this section applies of additional facilities for the care of children belonging to women workers, including suitable provision of facilities for washing and changing their clothing;

(c) requiring the provision in any factory of free milk or refreshment or both for such children;

(d) requiring that facilities shall be given in any factory for the mothers of such children to feed them at the necessary intervals.

49. Welfare officers.—(1) In every factory wherein five hundred or more workers are ordinarily employed the occupier shall employ in the factory such number of welfare officers as may be prescribed.

(2) The State Government may prescribe the duties, qualifications and conditions of service of officers employed under sub-section (1).

50. Power to make rules to supplement this Chapter.—The State Government may make rules—

(a) exempting, subject to compliance with such alternative arrangements for the welfare of workers as may be prescribed, any factory or class or description of factories from compliance with any of the provisions of this Chapter;

(b) requiring in any factory or class or description of factories that representatives of the workers employed in the factory shall be associated with the management of the welfare arrangements of the workers.

## CHAPTER VI

## WORKING HOURS OF ADULTS

51. Weekly hours.—No adult worker shall be required or allowed to work in a factory for more than forty-eight hours in any week.

52. Weekly holidays.—(1) No adult worker shall be required or allowed to work in a factory on the first day of the week (hereinafter referred to as the said day), unless—

(a) he has or will have a holiday for a whole day on one of the three days immediately before or after the said day, and

(b) the manager of the factory has, before the said day or the substituted day under clause (a), whichever is earlier,—

(i) delivered a notice at the office of the Inspector of his intention to require the worker to work on the said day and of the day which is to be substituted, and

(ii) displayed a notice to that effect in the factory:

Provided that no substitution shall be made which will result in any worker working for more than ten days consecutively without a holiday for a whole day.

(2) Notices given under sub-section (1) may be cancelled by a notice delivered at the office of the Inspector and a notice displayed in the factory not later than the day before the said day or the holiday to be cancelled, whichever is earlier.

(3) Where, in accordance with the provisions of sub-section (1), any worker works on the said day and has had a holiday on one of the three days immediately before it, that said day shall, for the purpose of calculating his weekly hours of work, be included in the preceding week.

53. Compensatory holidays.—(1) Where, as a result of the passing of an order or the making of a rule under the provisions of this Act exempting a factory or the workers therein from the provisions of section 52, a worker is deprived of any of the weekly holidays for which provision is made in sub-section (1) of that section, he shall be allowed, within the month in which the holidays were due to him or within the two months immediately following that month, compensatory holidays of equal number to the holidays so lost.

(2) The State Government may prescribe the manner in which the holidays for which provision is made in sub-section (1) shall be allowed.

54. Daily hours.—Subject to the provisions of section 51, not adult worker shall be required or allowed to work in a factory for more than nine hours in any day:

<sup>1</sup>[Provided that, subject to the previous approval of the Chief Inspector, the daily maximum specified in this section may be exceeded in order to facilitate the change of shifts.]

55. Intervals for rest.—<sup>2</sup>[(1)] <sup>3</sup>[The periods of work] of adult workers in a factory each day shall be so fixed that no period shall exceed five hours and that no worker shall work for more than five hours before he has had an interval for rest of at least half an hour.

<sup>1</sup>[(2) The State Government or, subject to the control of the State Government, the Chief Inspector, may, by written order and for the reasons specified therein, exempt any factory from the provisions of sub-section (1) so, however, that the total number of hours worked by a worker without an interval does not exceed six.]

56. Spread over.—The periods of work of an adult worker in a factory shall be so arranged that inclusive of his intervals for rest under section 55, they shall not spread over more than ten and a half hours in any day:

Provided that the Chief Inspector may, for reasons to be specified in writing increase the <sup>2</sup>[spread over up to twelve hours].

57. Night shifts.—Where a worker in a factory works on a shift which extends beyond midnight,—

(a) for the purposes of sections 52 and 53, a holiday for a whole day shall mean in his case a period of twenty-four consecutive hours beginning when his shift ends;

(b) the following day for him shall be deemed to be the period of twenty-four hours beginning when such shift ends, and the hours he has worked after midnight shall be counted in the previous day.

58. Prohibition of overlapping shifts.—(1) Work shall not be carried on in any factory by means of system of shifts so arranged that more than one relay of workers is engaged in work of the same kind at the same time.

<sup>3</sup>[(2) The State Government or subject to the control of the State Government, the Chief Inspector, may, by written order and for the reasons specified therein, exempt on such conditions as may be deemed expedient, any factory or class or description of factories or any department or section of a factory or any category or description of workers therein from the provisions of sub-section (1).]

59. Extra wages for overtime.—(1) Where a worker works in a factory for more than nine hours in any day or for more than forty-eight hours in any week, he shall, in respect of overtime work, be entitled to wages at the rate of twice his ordinary rate of wages.

<sup>4</sup>[(2) For the purposes of sub-section (1), “ordinary rate of wages” means the basic wages plus such allowances, including the cash equivalent of the advantage accruing through the concessional sale to workers of foodgrains and other articles, as the worker is for the time being entitled to, but does not include a bonus and wages for overtime work.

(3) Where any workers in a factory are paid on a piece rate basis, the time rate shall be deemed to be equivalent to the daily average of their full-time earnings for the days on which they actually worked on the same or identical job during the month immediately preceding the calendar month during which the overtime work was done, and such time rates shall be deemed to be ordinary rates of wages of those workers:

Provided that in the case of a worker who has not worked in the immediately preceding calendar month on the same or identical job, the time rate shall be deemed to be equivalent to the daily average of the earning of the worker for the days on which he actually worked in the week in which the overtime work was done.

Explanation.—For the purposes of this sub-section in computing the earnings for the days on which the worker actually worked such allowances, including the cash equivalent of the advantage accruing through the concessional sale to workers of foodgrains and other articles, as the worker is for the time being entitled to, shall be included but any bonus or wages for overtime work payable in relation to the period with reference to which the earnings are being computed shall be excluded.]

<sup>1</sup>[(4) The cash equivalent of the advantage accruing through the concessional sale to a worker of foodgrains and other articles shall be computed as often as may be prescribed on the basis of the maximum quantity of foodgrains and other articles admissible to a standard family.

Explanation 1.—“Standard family” means a family consisting of the worker, his or her spouse and two children below the age of fourteen years requiring in all three adult consumption units.

Explanation 2.—“Adult consumption unit” means the consumption unit of a male above the age of fourteen years; and the consumption unit of a female above the age of fourteen years and that of a child below the age of fourteen years shall be calculated at the rates of 8 and 6 respectively of one adult consumption unit.

(5) The State Government may make rules prescribing—

(a) the manner in which the cash equivalent of the advantage accruing through the concessional sale to a worker of foodgrains and other articles shall be computed; and

(b) the registers that shall be maintained in a factory for the purpose of securing compliance with the provisions of this section.]

60. Restriction on double employment.—No adult worker shall be required or allowed to work in any factory on any day on which he has already been working in any other factory, save in such circumstances as may be prescribed.

61. Notice of periods of work for adults.—(1) There shall be displayed and correctly maintained in every factory in accordance with the provisions of sub-section (2) of section 108, a notice of periods of work for adults, showing clearly for every day the periods during which adult workers may be required to work.

(2) The periods shown in the notice required by sub-section (1) shall be fixed beforehand in accordance with the following provisions of this section, and shall be such that workers working for those periods would not be working in contravention of any of the provisions of sections 51, 52, 54, <sup>2</sup>[ 55, 56 and 58].

(3) Where all the adult workers in a factory are required to work during the same periods, the manager of the factory shall fix those periods for such workers generally.

(4) Where all the adult workers in a factory are not required to work during the same periods, the manager of the factory shall classify them into groups according to the nature of their work indicating the number of workers in each group.

(5) For each group which is not required to work on a system of shifts, the manager of the factory shall fix the periods during which the group may be required to work.

(6) Where any group is required to work on a system of shifts and the relays are not to be subject to predetermined periodical changes of shifts, the manager of the factory shall fix the periods during which each relay of the group may be required to work.

(7) Where any group is to work on a system of shifts and the relays are to be subject to predetermined periodical changes of shifts, the manager of the factory shall draw up a scheme of shifts where under the periods during which any relay of the group may be required to work and the relay which will be working at any time of the day shall be known for any day.

(8) The State Government may prescribe forms of the notice required by sub-section (1) and the manner in which it shall be maintained.

(9) In the case of a factory beginning work after the commencement of this Act, a copy of the notice referred to in sub-section (1) shall be sent in duplicate to the Inspector before the day on which work is begun in the factory.

(10) Any proposed change in the system of work in any factory which will necessitate a change in the notice referred to in sub-section (1) shall be notified to the Inspector in duplicate before the change is made, and except with the previous sanction of the Inspector, no such change shall be made until one week has elapsed since the last change.

62. Register of adult workers.—(1) The manager of every factory shall maintain a register of adult workers, to be available to the Inspector at all times during working hours, or when any work is being carried on in the factory, showing—

(a) the name of each adult worker in the factory;

(b) the nature of his work;

(c) the group, if any, in which he is included;

(d) where his group works on shifts, the relay to which he is allotted;

(e) such other particulars as may be prescribed:

Provided that, if the Inspector is of opinion that any muster roll or register maintained as part of the routine of a factory gives in respect of any or all the workers in the factory the particulars required under this section, he may, by order in writing, direct that such muster roll or register shall to the corresponding extent be maintained in place of, and be treated as the register of adult workers in that factory.

<sup>1</sup>[(1A) No adult worker shall be required or allowed to work in any factory unless his name and other particulars have been entered in the register of adult workers.]

(2) The State Government may prescribe the form of the register of adult workers, the manner in which it shall be maintained and the period for which it shall be preserved.

63. Hours of work to correspond with notice under section 61 and register under section 62.—No adult worker shall be required or allowed to work in any factory otherwise than in accordance with the notice of periods of work for adults displayed in the factory and the entries made beforehand against his name in the register of adult workers of the factory.

64. Power to make exempting rules.—(1) The State Government may make rules defining the persons who hold positions of supervision or management or are employed in a confidential position in a factory [or empowering the Chief Inspector to declare any person, other than a person defined by such rules, as a person holding position of supervision or management or employed in a confidential position in a factory if, in the opinion of the Chief Inspector, such person holds such position or is so employed], and the provisions of this Chapter, other than the provisions of clause (b) of sub-section (1) of section 66 and of the proviso to that sub-section, shall not apply to any person so defined <sup>2</sup>[or declared]:

<sup>2</sup>[Provided that any person so defined or declared shall, where the ordinary rate of wages of such person <sup>3</sup>[does not exceed the wage limit specified in sub-section (6) of section 1 of the Payment of Wages Act, 1936 (4 of 1936), as amended from time to time], be entitled to extra wages in respect of overtime work under section 59.]

(2) The State Government may make rules in respect of adult workers in factories providing for the exemption, to such extent and subject to such conditions as may be prescribed—

(a) of workers engaged on urgent repairs, from the provisions of sections 51, 52, 54, 55 and 56;

(b) of workers engaged in work in the nature of preparatory or complementary work which must necessarily be carried on outside the limits laid down for the general working of the factory, from the provisions of sections 51, 54, 55 and 56;

(c) of workers engaged in work which is necessarily so intermittent that the intervals during which they do not work while on duty ordinarily amount to more than the intervals for rest required by or under section 55, from the provisions of sections 51, 54, 55 and 56;

(d) of workers engaged in any work which for technical reasons must be carried on continuously <sup>1</sup>\*\*\* from the provisions of sections 51, 52, 54, 55 and 56;

(e) of workers engaged in making or supplying articles of prime necessity which must be made or supplied every day, from the provisions of [section 51 and section 52];

(f) of workers engaged in a manufacturing process which cannot be carried on except during fixed seasons, from the provisions of <sup>2</sup>[section 51, section 52 and section 54];

(g) of workers engaged in a manufacturing process which cannot be carried on except at times dependent on the irregular action of natural forces, from the provisions of sections 52 and 55;

(h) of workers engaged in engine-rooms or boiler-houses or in attending to power-plant or transmission machinery, from the provisions of <sup>2</sup>[section 51 and section 52];

<sup>3</sup>[(i) of workers engaged in the printing of newspapers, who are held up on account of the breakdown of machinery, from the provisions of sections 51, 54 and 56.

Explanation.—In this clause the expression “newspapers'' has the meaning assigned to it in the Press and Registration of Books Act, 1867 (25 of 1867);

(j) of workers engaged in the loading or unloading of railway wagons, <sup>4</sup>[or lorries or truck] from the provisions of sections 51, 52, 54, 55 and 56];

<sup>4</sup>[(k) of workers engaged in any work, which is notified by the State Government in the Official Gazette as a work of national importance, from the provisions of section 51, section 52, section 54, section 55 and section 56.]

(3) Rules made under sub-section (2) providing for any exemption may also provide for any consequential exemption from the provisions of section 61 which the State Government may deem to be expedient, subject to such conditions as it may prescribe.

<sup>5</sup>[(4) In making rules under this section, the State Government shall not exceed, except in respect of exemption under clause (a) of sub-section (2), the following limits of work inclusive of overtime:—

(i) the total number of hours of work in any day shall not exceed ten;

(ii) the spread over, inclusive of intervals for rest, shall not exceed twelve hours in any one day:

Provided that the State Government may, in respect of any or all of the categories of workers referred to in clause (d) of sub-section (2), make rules prescribing the circumstances in which, and the conditions subject to which, the restrictions imposed by clause (i) and clause (ii) shall not apply in order to enable a shift worker to work the whole or part of a subsequent shift in the absence of a worker who has failed to report for duty;

<sup>4</sup>[(iii) the total number of hours of work in a week, including overtime, shall not exceed sixty;]

<sup>6</sup>[(iv)] the total number of hours of overtime shall not exceed fifty for any one quarter.

Explanation.—“Quarter” means a period of three consecutive months beginning on the 1st of January, the 1st of April, the 1st of July or the 1st of October.]

(5) Rules made under this section shall remain in force for not more than <sup>7</sup>[five years].

65. Power to make exempting orders.—(1) Where the State Government is satisfied that, owing to the nature of the work carried on or to other circumstances, it is unreasonable to require that the periods of work of any adult workers in any factory or class or description of factories should be fixed beforehand, it may, by written order, relax or modify the provisions of section 61 in respect of such workers therein, to such extent and in such manner as it may think fit, and subject to such conditions as it may deem expedient to ensure control over periods of work.

(2) The State Government or, subject to the control of the Stale Government, the Chief Inspector may by written order exempt, on such conditions as it or he may deem expedient, any or all of the adult workers in any factory or group or class or description of factories from any or all of the provisions of sections 51, 52, 54 and 56 on the ground that the exemption is required to enable the factory or factories to deal with an exceptional press of work.

<sup>1</sup>[(3) Any exemption granted under sub-section (2) shall be subject to the following conditions, namely:—

(i) the total number of hours of work in any day shall not exceed twelve;

(ii) the spread over, inclusive of intervals for rest, shall not exceed thirteen hours in any one day;

(iii) the total number of hours of work in any week, including overtime, shall not exceed sixty;

(iv) no worker shall be allowed to work overtime, for more than seven days at a stretch and the total number of hours of overtime work in any quarter shall not exceed seventy-five.

Explanation.—In this sub-section “quarter” has the same meaning as in sub-section (4) of section 64.]

2 \* \* \* \*

66. Further restrictions on employment of women.—(1) The provisions of this Chapter shall, in their application to women in factories, be supplemented by the following further restrictions, namely:—

(a) no exemption from the provisions of section 54 may be granted in respect of any woman;

(b) no woman shall be <sup>3</sup>[required or allowed to work in any factory] except between the hours of 6 A.M. and 7 P.M.:

Provided that the State Government may, by notification in the Official Gazette, in respect of <sup>4</sup>[any factory or group or class or description of factories,] very the limits laid down in clause (b), but so that no such variation shall authorise the employment of any woman between the hours of 10 P.M. and 5 A.M.:

<sup>5</sup>[(c) there shall be no change of shifts except after a weekly holiday or any other holiday.]

(2) The State Government may make rules providing for the exemption from the restrictions set out in sub-section (1), to such extent and subject to such conditions as it may prescribe, of women working in fish-curing or fish-canning factories, where the employment of women beyond the hours specified in the said restrictions is necessary to prevent damage to, or deterioration in, any raw material.

(3) The rules made under sub-section (2) shall remain in force for not more than three years at a time.

## CHAPTER VII EMPLOYMENT OF YOUNG PERSONS

67. Prohibition of employment of young children.—No child who has not completed his fourteenth year shall be required or allowed to work in any factory.

68. Non-adult workers to carry tokens.—A child who has completed his fourteenth year or an adolescent shall not be required or allowed to work in any factory unless—

(a) a certificate of fitness granted with reference to him under section 69 is in the custody of the manager of the factory, and

(b) such child or adolescent carries while he is at work a token giving a reference to such certificate.

69. Certificates of fitness.—(1) A certifying surgeon shall, on the application of any young person or his parent or guardian accompanied by a document signed by the manager of a factory that such person will be employed therein if certified to be fit for work in a factory, or on the application of the manager of the factory in which any young person wishes to work, examine such person and ascertain his fitness for work in a factory.

(2) The certifying surgeon, after examination, may grant to such young person, in the prescribed form, or may renew—

(a) a certificate of fitness to work in a factory as a child, if he is satisfied that the young person has completed his fourteenth year, that he has attained the prescribed physical standards and that he is fit for such work;

(b) a certificate of fitness to work in a factory as an adult, if he is satisfied that the young person has completed his fifteenth year, and is fit for a full day's work in a factory:

Provided that unless the certifying surgeon has personal knowledge of the place where the young person proposes to work and of the manufacturing process in which he will be employed, he shall not grant or renew a certificate under this sub-section until he has examined such place.

(3) A certificate of fitness granted or renewed under sub-section (2)—

(a) shall be valid only for a period of twelve months from the date thereof:

(b) may be made subject to conditions in regard to the nature of the work in which the young person may be employed, or requiring re-examination of the young person before the expiry of the period of twelve months.

(4) A certifying surgeon shall revoke any certificate granted or renewed under sub-section (2) if in his opinion the holder of it is no longer fit to work in the capacity stated therein in a factory.

(5) Where a certifying surgeon refuses to grant or renew a certificate or a certificate of the kind requested or revokes a certificate, he shall, if so requested by any person who could have applied for the certificate or the renewal thereof, state his reasons in writing for so doing.

(6) Where a certificate under this section with reference to any young person is granted or renewed subject to such conditions as are referred to in clause (b) of sub-section (3), the young person shall not be required or allowed to work in any factory except in accordance with those conditions.

(7) Any fee payable for a certificate under this section shall be paid by the occupier and shall not be recoverable from the young person, his parents or guardian.

70. Effect of certificate of fitness granted to adolescent.—(1) An adolescent who has been granted a certificate of fitness to work in a factory as an adult under clause (b) of sub-section (2) of section 69, and who while at work in a factory carries a token giving reference to the certificate, shall be deemed to be an adult for all the purposes of Chapter VI and VIII.

1 \* \* \* \*

<sup>2</sup>[(1A) No female adolescent or a male adolescent who has not attained the age of seventeen years but who has been granted a certificate of fitness to work in a factory as an adult, shall be required or allowed to work in any factory except between 6 A.M. and 7 P.M.:

Provided that the State Government may, by notification in the Official Gazelle, in respect of any factory or group or class or description of factories,—

(i) vary the limits laid down in this sub-section so, however, that no such section shall authorise the employment of any female adolescent between 10 P.M. and 5 A.M.

(ii) grant exemption from the provisions of this sub-section in case of serious emergency where national interest is involved.]

(2) An adolescent who has not been granted a certificate of fitness to work in a factory as an adult under the aforesaid clause (b) shall, notwithstanding his age, be deemed to be a child for all the purposes of this Act.

71. Working hours for children.—(1) No child shall be employed or permitted to work, in any factory—

(a) for more than four and a half hours in any day;

<sup>1</sup>[(b) during the night.

Explanation.—For the purpose of this sub-section “night” shall mean a period of at least twelve consecutive hours which shall include the interval between 10 P.M. and 6 A.M.]

(2) The period of work of all children employed in a factory shall be limited to two shifts which shall not overlap or spread over more than five hours each; and each child shall be employed in only one of the relays which shall not, except with the previous permission in writing of the Chief Inspector, be changed more frequently than once in a period of thirty days.

(3) The provisions of section 52 shall apply also to child workers and no exemption from the provisions of that section may be granted in respect of any child.

(4) No child shall be required or allowed to work in any factory on any day on which he has already been working in another factory.

<sup>2</sup>[(5) No female child shall be required or allowed to work in any factory except between 8 A.M. and 7 P.M.]

72. Notice of periods of work for children.—(1) There shall be displayed and correctly maintained in every factory in which children are employed, in accordance with the provisions of sub-section (2) of section 108 a notice of periods of work for children, showing clearly for every day the periods during which children may be required or allowed to work.

(2) The periods shown in the notice required by sub-section (1) shall be fixed beforehand in accordance with the method laid down for adult workers in section 61, and shall be such that children working for those periods would not be working in contravention of any of the provisions of section 71.

(3) The provisions of sub-sections (8), (9) and (10) of section 61 shall apply also to the notice required by sub-section (1) of this section.

73. Register of child workers.—(1) The manager of every factory in which children are employed shall maintain a register of child workers, to be available to the Inspector at all times during working hours or when any work is being carried on in a factory, showing—

(a) the name of each child worker in the factory,

(b) the nature of his work,

(c) the group, if any, in which he is included,

(d) where his group works on shifts, the relay to which he is allotted, and

(e) the number of his certificate of fitness granted under section 69.

<sup>3</sup>[(1A) No child worker shall be required or allowed to work in any factory unless his name and other particulars have been entered in the register of child workers.]

(2) The State Government may prescribe the form of the register of child workers, the manner in which it shall be maintained and the period for which it shall be preserved.

74. Hours of work to correspond with notice under section 72 and register under section 73.—No child worker shall be employed in any factory otherwise than in accordance with the notice of periods of work for children displayed in the factory and the entries made beforehand against his name in the register of child workers of the factory.

75. Power to require medical examination.—Where an Inspector is of opinion—

(a) that any person working in a factory without a certificate of fitness is a young person, or

(b) that a young person working in a factory with a certificate of fitness is no longer fit to work in the capacity stated therein,

he may serve on the manager of the factory a notice requiring that such person or young person, as the case may be, shall be examined by a certifying surgeon, and such person or young person shall not, if the Inspector so directs, be employed, or permitted to work, in any factory until he has been so examined and has been granted a certificate of fitness or a fresh certificate of fitness, as the case may be, under section 69, or has been certified by the certifying surgeon examining him not to be a young person.

## 76. Power to make rules.—The State Government may make rules—

(a) prescribing the forms of certificates of fitness to be granted under section 69, providing for the grant of duplicates in the event of loss of the original certificates, and fixing the fees which may be charged for such certificates and renewals thereof and such duplicates;

(b) prescribing the physical standards to be attained by children and adolescents working in factories;

(c) regulating the procedure of certifying surgeons under this Chapter;

(d) specifying other duties which certifying surgeons may be required to perform in connection with the employment of young persons in factories, and fixing the fees which may be charged for such duties and the persons by whom they shall be payable.

77. Certain other provisions of law not barred.—The provisions of this Chapter shall be in addition to, and not in derogation of, the provisions of the Employment of Children Act, 1938 (26 of 1938).

## <sup>1</sup>[CHAPTER VIII

## ANNUAL LEAVE WITH WAGES

78. Application of Chapter.—(1) The provisions of this Chapter shall not operate to the prejudice of any right to which a worker may be entitled under any other law or under the terms of any award, [agreement (including settlement)] or contract of service:

<sup>3</sup>[Provided that if such award, agreement (including settlement) or contract of service provides for a longer annual leave with wages than provided in this Chapter, the quantum of leave, which the worker shall be entitled to, shall be in accordance with such award, agreement or contract of service, but in relation to matters not provided for in such award, agreement or contract of service or matters which are provided for less favourably therein, the provisions of sections 79 to 82, so far as may be, shall apply.]

(2) The provisions of this Chapter shall not apply to workers <sup>4</sup>[in any factory] of any railway administered by the Government, who are governed by leave rules approved by the Central Government.

79. Annual leave with wages.—(1) Every worker who has worked for a period of 240 days or more in a factory during a calendar year shall be allowed during the subsequent calendar year, leave with wages for a number of days calculated at the rate of—

(i) if an adult, one day for every twenty days of work performed by him during the previous calendar year;

(ii) if a child, one day for every fifteen days of work performed by him during the previous calendar year.

Explanation 1.—For the purpose of this sub-section—

(a) any days of lay off, by agreement or contract or as permissible under the standing orders;

(b) in the case of a female worker, maternity leave for any number of days not exceeding twelve weeks; and

(c) the leave earned in the year prior to that in which the leave is enjoyed,

shall be deemed to be days on which the worker has worked in a factory for the purpose of computation of the period of 240 days or more, but he shall not earn leave for these days.

Explanation 2.—The leave admissible under this sub-section shall be exclusive of all holidays whether occurring during or at either end of the period of leave.

(2) A worker whose service commences otherwise than on the first day of January shall be entitled to leave with wages at the rate laid down in clause (i) or, as the case may be, clause (ii) of sub-section (1) if he has worked for two-thirds of the total number of days in the remainder of the calendar year.

<sup>1</sup>[(3) If a worker is discharged or dismissed from service or quits his employment or is superannuated or dies while in service, during the course of the calendar year, he or his heir or nominee, as the case may be, shall be entitled to wages in lieu of the quantum of leave to which he was entitled immediately before his discharge, dismissal, quitting of employment, superannuation or death calculated at the rates specified in sub-section (1), even if he had not worked for the entire period specified in sub-section (1) or sub-section (2) making him eligible to avail of such leave, and such payment shall be made—

(i) where the worker is discharged or dismissed or quits employment, before the expiry of the second working day from the date of such discharge, dismissal or quitting; and

(ii) where the worker is superannuated or dies while in service, before the expiry of two months from the date of such superannuation or death.]

(4) In calculating leave under this section, fraction of leave of half a day or more shall be treated as one full day’s leave, and fraction of less than half a day shall be omitted.

(5) If a worker does not in any one calendar year take the whole of the leave allowed to him under sub-section (1) or sub-section (2), as the case may be, any leave not taken by him shall be added to the leave to be allowed to him in the succeeding calendar year:

Provided that the total number of days of leave that may be carried forward to a succeeding year shall not exceed thirty in the case of an adult or forty in the case of a child:

Provided further that a worker, who has applied for leave with wages but has not been given such leave in accordance with any scheme laid down in sub-sections (8) and (9) <sup>2</sup>[or in contravention of sub-section (10)] shall be entitled to carry forward the <sup>3</sup>[leave refused] without any limit.

(6) A worker may at any time apply in writing to the manager of a factory not less than fifteen days before the date on which he wishes his leave to begin, to take all the leave or any portion thereof allowable to him during the calendar year:

Provided that the application shall be made not less than thirty days before the date on which the worker wishes his leave to begin, if he is employed in a public utility service as defined in clause (ii) of section 2 of the Industrial Disputes Act. 1947 (14 of 1947):

Provided further that the number of times in which leave may be taken during any year shall not exceed three.

(7) If a worker wants to avail himself of the leave with wages due to him to cover a period of illness, he shall be granted such leave even if the application for leave is not made within the time specified in sub-section (6); and in such a case wages as admissible under section 81 shall be paid not later than fifteen days, or in the case of a public utility service not later than thirty days from the date of the application for leave.

(8) For the purpose of ensuring the continuity of work, the occupier or manager of the factory, in agreement with the Works Committee of the factory constituted under section 3 of the Industrial Disputes Act, 1947 (14 of 1947), or a similar Committee constituted under any other Act or if there is no such Works Committee or a similar Committee in the factory, in agreement with the representatives of the workers therein chosen in the prescribed manner, may lodge with the Chief Inspector a scheme in writing whereby the grant of leave allowable under this section may be regulated.

(9) A scheme lodged under sub-section (8) shall be displayed at some conspicuous and convenient places in the factory and shall be in force for a period of twelve months from the date on which it comes into force, and may thereafter be renewed with or without modification for a further period of twelve months at a time, by the manager in agreement with the Works Committee or a similar Committee, or as the case may be, in agreement with the representatives of the workers as specified in sub-section (8), and a notice of renewal shall be sent to the Chief Inspector before it is renewed.

(10) An application for leave which does not contravene the provisions of sub-section (6) shall not be refused, unless refusal is in accordance with the scheme for the time being in operation under sub-sections (8) and (9).

(11) If the employment of a worker who is entitled to leave under sub-section (1) or sub-section (2), as the case may be, is terminated by the occupier before he has taken the entire leave to which he is entitled, or if having applied for and having not been granted such leave, the worker quits his employment, before he has taken the leave, the occupier of the factory shall pay him the amount payable under section 80 in respect of the leave not taken, and such payment shall be made, where the employment of the worker is terminated by the occupier, before the expiry of the second working day after such termination, and where a worker who quits his employment, on or before the next pay day.

(12) The unavailed leave of a worker shall not be taken into consideration in computing the period of any notice required to be given before discharge or dismissal.

80. Wages during leave period.—(1) For the leave allowed to him under <sup>1</sup>[section 78 or section 79, as the case may be,] a worker <sup>2</sup>[shall be entitled to wages] at a rate equal to the daily average of his total full time earnings for the days on which <sup>3</sup>[he actually worked] during the month immediately preceding his leave, exclusive of any overtime and bonus but inclusive of dearness allowance and the cash equivalent of the advantage accruing through the concessional sale to the worker of food grains and other articles:

<sup>4</sup>[Provided that in the case of a worker who has not worked on any day during the calendar month immediately preceding his leave, he shall be paid at a rate equal to the daily average of his total full time earnings for the days on which he actually worked during the last calendar month preceding his leave, in which he actually worked, exclusive of any overtime and bonus but inclusive of dearness allowance and the cash equivalent of the advantage accruing through the concessional sale to the workers of food grains and other articles.]

(2) The cash equivalent of the advantage accruing through the concessional sale to the worker of food grains and other articles shall be computed as often as may be prescribed, on the basis of the maximum quantity of food grains and other articles admissible to a standard family.

Explanation 1.—“Standard family” means a family consisting of a worker, his or her spouse and two children below the age of fourteen years requiring in all three adult consumption units.

Explanation 2.—“Adult consumption unit” means the consumption unit of a male above the age of fourteen years; and the consumption unit of a female above the age of fourteen years and that of a child below the age of fourteen years shall be calculated at the rates of 8 and 6 respectively of one adult consumption unit.

(3) The State Government may make rules prescribing—

(a) the manner in which the cash equivalent of the advantage accruing through the concessional sale to a worker of food grains and other articles shall be computed; and

(b) the registers that shall be maintained in a factory for the purpose of securing compliance with the provisions of this section.

81. Payment in advance in certain cases.—A worker who has been allowed leave for not less than four days, in the case of an adult, and five days, in the case of a child, shall, before his leave begins be paid the wages due for the period of the leave allowed.

82. Mode of recovery of unpaid wages.—Any sum required to be paid by an employer, under his Chapter but not paid by him shall be recoverable as delayed wages under the provisions of the Payment of Wages Act, 1936 (4 of 1936).

83. Power to make rules.—The State Government may make rules directing managers of factories to keep registers containing such particulars as may be prescribed and requiring the registers to be made available for examination by Inspectors.

84. Power to exempt factories.—Where the State Government is satisfied that the leave rules applicable to workers in a factory provide benefits which in its opinion are not less favourable than those for which this Chapter makes provision it may, by written order; exempt the factory from all or any of the provisions of this Chapter subject to such conditions as may be specified in the order.]

<sup>1</sup>[Explanation.—For the purposes of this section, in deciding whether the benefits which are provided for by any leave rules are less favourable than those for which this Chapter makes provision, or not, the totality of the benefits shall be taken into account.]

## CHAPTER IX

## SPECIAL PROVISIONS

85. Power to apply the act to certain premises.—(1) The State Government may, by notification in the Official Gazette, declare that all or any of the provisions of this Act shall apply to any place wherein a manufacturing process is carried on with or without the aid of power or is so ordinarily carried on, notwithstanding that—

(i) the number of persons employed therein is less than ten, if working with the aid of power and less than twenty if working without the aid of power, or

(ii) the persons working therein are not employed by the owner thereof but are working with the permission of, or under agreement with, such owner:

Provided that the manufacturing process is not being carried on by the owner only with the aid of his family.

(2) After a place is so declared, it shall be deemed to be a factory for the purposes of this Act, and the owner shall be deemed to be the occupier, and any person working therein, a worker.

Explanation.—For the purposes of this section, “owner” shall include a lessee or mortgage with possession of the premises.

86. Power to exempt public institutions.—The State Government may exempt, subject to such conditions as it may consider necessary, any workshop or workplace where a manufacturing process is carried on and which is attached to a public institution maintained for the purposes of education, <sup>2</sup>[training, research] or reformation, from all or any of the provisions of this Act:

Provided that no exemption shall be granted from the provisions relating to hours of work and holidays, unless the persons having the control of the institution submit, for the approval of the State Government, a scheme for the regulation of the hours of employment, intervals for meals, and holidays of the persons employed in or attending the institution or who are inmates of the institution, and the State Government is satisfied that the provisions of the scheme are not less favourable than the corresponding provisions of this Act.

87. Dangerous operations.—Where the State Government is of opinion that any [manufacturing process or operation] carried on in a factory exposes any persons employed in it to a serious risk of bodily injury, poisoning or disease, it may make rules applicable to any factory or class or description of factories in which the [manufacturing process or operation] is carried on—

(a) specifying the <sup>1</sup>[manufacturing process or operation] and declaring it to be dangerous;

(b) prohibiting or restricting the employment of women, adolescents or children in the <sup>1</sup>[manufacturing process or operation];

(c) providing for the periodical medical examination of persons employed, or seeking to be employed, in the <sup>1</sup>[manufacturing process or operation], and prohibiting the employment or persons not certified as fit for such employment [and requiring the payment by the occupier of the factory of fees for such medical examination];

(d) providing for the protection of all persons employed in the <sup>1</sup>[manufacturing process or operation] or in the vicinity of the places where it is carried on;

(e) prohibiting, restricting or controlling the use of any specified materials or processes in connection with the <sup>1</sup>[manufacturing process or operation];

<sup>2</sup>[(f) requiring the provision of additional welfare amenities and sanitary facilities and the supply of protective equipment and clothing, and laying down the standards thereof, having regard to the dangerous nature of the manufacturing process or operation.

<sup>4</sup>[87A. Power to prohibit employment on account of serious hazard.—(1) Where it appears to the Inspector that conditions in a factory or part thereof are such that they may cause serious hazard by way of injury or death to the persons employed therein or to the general public in the vicinity, he may, by order in writing to the occupier of the factory, state the particulars in respect of which he considers the factory or part thereof to be the cause of such serious hazard and prohibit such occupier from employing any person in the factory or any part thereof other than the minimum number of persons necessary to attend to the minimum tasks till the hazard is removed.

(2) Any order issued by the Inspector under sub-section (1) shall have effect for a period of three days until extended by the Chief Inspector by a subsequent order.

(3) Any person aggrieved by an order of the Inspector under sub-section (1), and the Chief Inspector under sub-section (2), shall have the right to appeal to the High Court.

(4) Any person whose employment has been affected by an order issued under sub-section (1), shall be entitled to wages and other benefits and it shall be the duty of the occupier to provide alternative employment to him wherever possible and in the manner prescribed.

(5) The provisions of sub-section (4) shall be without prejudice to the rights of the parties under the Industrial Disputes Act, 1947 (14 of 1947).]

88. Notice of certain accidents.—<sup>1</sup>[(1)] Where in any factory an accident occurs which causes death, or which causes any bodily injury by reason of which the person injured is prevented from working for a period of forty-eight hours or more immediately following the accident, or which is of such nature as may be prescribed in this behalf, the manager of the factory shall send notice thereof to such authorities, and in such form and within such time, as may be prescribed.

<sup>2</sup>[(2) Where a notice given under sub-section (1) relates to an accident causing death, the authority to whom the notice is sent shall make an inquiry into the occurrence within one month of the receipt of the notice or, if such authority is not the Inspector, cause the Inspector to make an inquiry within the said period.

(3) The State Government may make rules for regulating the procedure at inquiries under this section.]

<sup>3</sup>[88A. Notice of certain dangerous occurrences.—Where in a factory any dangerous occurrence of such nature as may be prescribed occurs, whether causing any bodily injury or disability or not, the manager of the factory shall send notice thereof to such authorities, and in such form and within such time, as may be prescribed.]

89. Notice of certain diseases.—(1) Where any worker in a factory contracts any disease specified in <sup>4</sup>[the Third Schedule], the manager of the factory shall send notice thereof to such authorities, and in such form and within such time, as may be prescribed.

(2) If any medical practitioner attends on a person who is or has been employed in a factory, and who is, or is believed by the medical practitioner to be, suffering from any disease specified in <sup>4</sup>[the Third Schedule], the medical practitioner shall without delay send a report in writing to the office of the Chief Inspector stating—

(a) the name and full postal address of the patient,

(b) the disease from which he believes the patient to be suffering, and

(c) the name and address of the factory in which the patient is, or was last, employed.

(3) Where the report under sub-section (2) is confirmed to the satisfaction of the Chief Inspector, by the certificate of a certifying surgeon or otherwise, that the person is suffering from a disease specified in <sup>4</sup>[the Third Schedule], he shall pay to the medical practitioner such fee as may be prescribed, and the fee so paid shall be recoverable as an arrear of land-revenue from the occupier of the factory in which the person contracted the disease.

(4) If any medical practitioner fails to comply with the provisions of sub-section (2), he shall be punishable with fine which may extend to <sup>5</sup>[one thousand rupees].

<sup>6</sup>[(5) The Central Government may, by notification in the Official Gazette, add to or alter the Third Schedule and any such addition or alteration shall have effect as if it had been made by this Act.]

90. Power to direct enquiry into cases of accident or disease.—(1) The State Government may, if it considers it expedient so to do, appoint a competent person to inquire into the causes of any accident occurring in a factory or into any case where a disease specified in <sup>7</sup>[the Third Schedule] has been, or is suspected to have been contracted in a factory, and may also appoint one or more persons possessing legal or special knowledge to act as assessors in such inquiry.

(2) The person appointed to hold an inquiry under this section shall have all the powers of a Civil Court under the Code of Civil Procedure, 1908 (5 of 1908), for the purposes of enforcing the attendance of witnesses and compelling the production of documents and material objects, and may also, so far as may be necessary for the purposes of the inquiry, exercise any of the powers of an Inspector under this Act; and every person required by the person making the inquiry to furnish any information shall be deemed to be legally bound so to do within the meaning of section 176 of the Indian Penal Code (45 of 1860).

(3) The person holding an inquiry under this section shall make a report to the State Government stating the causes of the accident, or as the case may be, disease, and any attendant circumstances, and addition any observations which he or any of the assessors may think fit to make.

(4) The State Government may, if it thinks fit, cause to be published any report made under this section or any extracts therefrom.

(5) The State Government may make rules for regulating the procedure at inquiries under this section.

91. Power to take samples.—(1) An Inspector may at any time during the normal working hours of a factory, after informing the occupier or manager of the factory or other person for the time being purporting to be in charge of the factory, take in the manner hereinafter provided a sufficient sample of any substances used or intended to be used in the factory, such use being—

(a) in the belief of the Inspector in contravention of any of the provisions of this Act or the rules made thereunder, or

(b) in the opinion of the Inspector likely to cause bodily injury to, or injury to the health of, workers in the factory.

(2) Where the Inspector takes a sample under sub-section (1), he shall, in the presence of the person informed under that sub-section unless such person wilfully absents himself, divide the sample into three portions and effectively seal and suitably mark them, and shall permit such person to add his own seal and mark thereto.

(3) The person informed as aforesaid shall, if the Inspector so requires, provide the appliances for dividing, sealing and marking the sample taken under this section.

(4) The Inspector shall—

(a) forthwith give one portion of the sample to the person informed under sub-section (1);

(b) forthwith send the second portion to a Government Analyst for analysis and report thereon;

(c) retain the third portion for production to the Court before which proceedings, if any, are instituted in respect of the substance.

(5) Any document purporting to be a report under the hand of any Government Analyst upon any substance submitted to him for analysis and report under this section, may be used as evidence in any proceedings instituted in respect of the substance.

<sup>1</sup>[91A. Safety and occupational health surveys.—(1) The Chief Inspector, or the Director General of Factory Advice Service and Labour Institutes, or the Director General of Health Services, to the Government of India, or such other officer as may be authorised in this behalf by the State Government or the Chief Inspector or the Director General of Factory Advice Service and Labour Institutes or the Director General of Health Services may, at any time during the normal working hours of a factory, or at any other time as is found by him to be necessary, after giving notice in writing to the occupier or manager of the factory or any other person who for the time being purports to be in charge of the factory, undertake safety and occupational health surveys, and such occupier or manager or other person shall afford all facilities for such survey, including facilities for the examination and testing of plant and machinery and collection of samples and other data relevant to the survey.

(2) For the purpose of facilitating surveys under sub-section (1) every worker shall, if so required by the person conducting the survey, present himself to undergo such medical examination as may be considered necessary by such person and furnish all information in his possession and relevant to the survey.

(3) Any time spent by a worker for undergoing medical examination or furnishing information under sub-section (2) shall, for the purpose of calculating wages and extra wages for overtime work, be deemed to be time during which such worker worked in the factory.]

<sup>1</sup>[Explanation.—For the purposes of this section, the report, if any, submitted to the State Government by the person conducting the survey under sub-section (1) shall be deemed to be a report submitted by an Inspector under this Act.]

## CHAPTER X

## PENALTIES AND PROCEDURE

92. General penalty for offences.—Save as is otherwise expressly provided in this Act and subject to the provisions of section 93 , if in, or in respect of, any factory there is any contravention of any of the provisions of this Act or of any rules made thereunder or of any order in writing given thereunder, the occupier and manager of the factory shall each be guilty of an offence and punishable with imprisonment for a term which may extend to <sup>2</sup>[two years] or with fine which may extend to <sup>3</sup>[one lakh rupees] or with both, and if the contravention is continued after conviction, with a further fine which may extend to <sup>4</sup>[one thousand rupees] for each day on which the contravention is so continued:

<sup>5</sup>[Provided that where contravention of any of the provisions of Chapter IV or any rule made thereunder or under section 87 has resulted in an accident causing death or serious bodily injury, the fine shall not be less than <sup>6</sup>[twenty-five thousand rupees] in the case of an accident causing death, and <sup>7</sup>[five thousand rupees] in the case of an accident causing serious bodily injury.

Explanation.—In this section and in section 94 “serious bodily injury” means an injury which involves, or in all probability will involve, the permanent loss of the use of, or permanent injury to, any limb or the permanent loss of, or injury to, sight or hearing, or the fracture of any bone, but shall not include, the fracture of bone or joint (not being fracture of more than one bone or joint) of any phalanges of the hand or foot.]

<sup>8</sup>[93. Liability of owner of premises in certain circumstances.—(1) Where in any premises separate buildings are leased to different occupiers for use as separate factories, the owner of the premises shall be responsible for the provision and maintenance of common facilities and services, such as approach roads, drainage, water supply, lighting and sanitation.

(2) The Chief Inspector shall have, subject to the control of the State Government, power to issue orders to the owner of the premises in respect of the carrying out of the provisions of sub-section (1).

(3) Where is any premises, independent or self-containted, floors or flats are leased to different occupiers for use as separate factories, the owner of the premises shall be liable as if he were the occupier or manager of a factory, for any contravention of the provisions of this Act in respect of—

(i) latrines, urinals and washing facilities in so far as the maintenance of the common supply of water for these purposes is concerned;

(ii) fencing of machinery and plant belonging to the owner and not specifically entrusted to the custody or use of an occupier;

(iii) safe means of access to the floors or flats and maintenance and cleanliness of staircases and common passages;

(iv) precautions in case of fire;

(v) maintenance of hoists and lifts; and

(vi) maintenance of any other common facilities provided in the premises.

(4) The Chief Inspector shall have, subject to the control of the State Government, power to issue orders to the owner of the premises in respect of the carrying out the provisions of sub-section (3).

(5) The provisions of sub-section (3) relating to the liability of the owner shall apply where in any premises independent rooms with common latrines, urinals and washing facilities are leased to different occupiers for use as separate factories:

Provided that the owner shall be responsible also for complying with the requirements relating to the provision and maintenance of latrines, urinals and washing facilities.

(6) The Chief Inspector shall have, subject to the control of the State Government, the power to issue orders to the owner of the premises referred to in sub-section (5) in respect of the carrying out of the provisions of section 46 or section 48.

(7) Where in any premises portions of a room or a shed are leased to different occupiers for use as separate factories, the owner of the premises shall be liable for any contravention of the provisions of—

(i) Chapter III, except sections 14 and 15;

(ii) Chapter IV, except sections 22, 23, 27, 34, 35 and 36:

Provided that in respect of the provisions of sections 21, 24 and 32 the owner's liability shall be only in so far as such provisions relate to things under his control:

Provided further that the occupier shall be responsible for complying with the provisions of Chapter IV in respect of plant and machinery belonging to or supplied by him;

(iii) section 42.

(8) The Chief Inspector shall have, subject to the control of the State Government, power to issue orders to the owner of the premises in respect of the carrying out the provisions of sub-section (7).

(9) In respect of sub-sections (5) and (7), while computing for the purposes of any of the provisions of this Act the total number of workers employed, the whole of the premises shall be deemed to be a single factory.]

94. Enhanced penalty after previous conviction.—<sup>1</sup>[(1)] If any person who has been convicted of any offence punishable under section 92 is again guilty of an offence involving a contravention of the same provision, he shall be punishable on a subsequent conviction with imprisonment for a term which may extend to <sup>2</sup>[three years] or with fine <sup>3</sup>[which shall not be less than <sup>4</sup>[ten thousand rupees] but which may extend to <sup>5</sup>[two lakh rupees]] or with both:

<sup>6</sup>[Provided that the court may, for any adequate and special reasons to be mentioned in the judgment, impose a fine of less than <sup>4</sup>[ten thousand rupees]:

Provided further that where contravention of any of the provisions of Chapter IV or any rule made thereunder or under section 87 has resulted in an accident causing death or serious bodily injury, the fine shall not be less than <sup>1</sup>[thirty-five thousand rupees] in the case of an accident causing death and <sup>2</sup>[ten thousand rupees] in the case of an accident causing serious bodily injury.]

<sup>3</sup>[(2) For the purposes of sub-section (1), no cognizance shall be taken of any conviction made more than two years before the commission or the offence for which the person is subsequently being convicted.]

95. Penalty for obstructing Inspector.—Whoever wilfully obstructs an Inspector in the exercise of any power conferred on him by or under this Act, or fails to produce on demand by an Inspector any registers or other documents in his custody kept in pursuance of this Act or of any rules made thereunder, or conceals or prevents any worker in a factory from appearing before, or being examined by, an Inspector, shall be punishable with imprisonment for a term which may extend to <sup>4</sup>[six months] or with fine which may extend to <sup>5</sup>[ten thousand rupees] or with both.

96. Penalty for wrongfully disclosing results of analysis under section 91.—Whoever, except in so far as it may be necessary for the purposes of a prosecution for any offence punishable under this Act, publishes or discloses to any person the results of an analysis made under section 91, shall be punishable with imprisonment for a term which may extend to <sup>6</sup>[six months] or with fine which may extend to <sup>7</sup>[ten thousand rupees] or with both.

<sup>8</sup>[96A. Penalty for contravention of the provisions of sections 41B, 41 C and 41 H.—(1) Whoever Whoever fails to comply with or contravenes any of the provisions of section 41B , 41 C or 41 H or the rules made thereunder, shall, in respect of such failure or contravention, be punishable with imprisonment for a term which may extend to seven years and with fine which may extend to two lakh rupees, and in case the failure or contravention continues, with additional fine which may extend to five thousand rupees for every day during which such failure or contravention continues after the conviction for the first such failure or contravention.

(2) If the failure or contravention referred to in sub-section (1) continues beyond a period of one year after the date of conviction, the offender shall be punishable with imprisonment for a term which may extend to ten years.]

97. Offences by workers.—(1) Subject to the provisions of section 111, if any worker employed in a factory contravenes any provision of this Act or any rules or orders made thereunder, imposing any duty or liability on workers, he shall be punishable with fine which may extend to <sup>9</sup>[five hundred rupees].

(2) Where a worker is convicted of an offence punishable under sub-section (1) the occupier or manager of the factory shall not be deemed to be guilty of an offence in respect of that contravention, unless it is proved that he failed to take all reasonable measures for its prevention.

98. Penalty for using false certificate of fitness.—Whoever knowingly uses or attempts to use, as a certificate of fitness granted to himself under section 70 , a certificate granted to another person under that section, or who, having procured such a certificate, knowingly allows it to be used, or an attempt to use it to be made, by another person, shall be punishable with imprisonment for a term which may extend to <sup>10</sup>[two months] or with fine which may extend to <sup>11</sup>[one thousand rupees] or with both.

99. Penalty for permitting double employment of child.—If a child works in a factory on any day on which he has already been working in another factory, the parent or guardian of the child or the person having custody of or control over him or obtaining any direct benefit from his wages, shall be punishable with fine which may extend to <sup>1</sup>[one thousand rupees], unless it appears to the Court that the child so worked without the consent or connivance of such parent, guardian or person.

100. [Determination of occupier in certain cases.] Rep. by the Factories (Amendment) Act, 1987 (20 of 1987), s. 38 (w.e.f. 1-12-1987).

101. Exemption of occupier or manager from liability in certain cases.—Where the occupier or manager of a factory is charged with an offence punishable under this Act, he shall be entitled, upon complaint duly made by him and on giving to the prosecutor not less than three clear days' notice in writing of his intention so to do, to have any other person whom he charges as the actual offender brought before the Court at time appointed for hearing the charge; and if, after the commission of the offence has been proved, the occupier or manager of the factory, as the case may be, proves to the satisfaction of the Court—

(a) that he has used due diligence to enforce the execution of this Act, and

(b) that the said other person committed the offence in question without his knowledge, consent or connivance,

that other person shall be convicted of the offence and shall be liable to the like punishment as if he were the occupier or manager of the factory, and the occupier or manager, as the case may be, shall be discharged from any liability under this Act in respect of such offence:

Provided that in seeking to prove as aforesaid, the occupier or manager of the factory, as the case may be, may be examined on oath, and his evidence and that of any witness whom he calls in his support shall be subject to cross-examination on behalf of the person he charges as the actual offender and by the prosecutor:

Provided further that, if the person charged as the actual offender by the occupier or manager cannot be brought before the Court at the time appointed for hearing the charge, the Court shall adjourn the hearing from time to time for a period not exceeding three months and if by the end of the said period the person charged as the actual offenders cannot still be brought before the Court, the Court shall proceed to hear the charge against the occupier or manager and shall, if the offence be proved, convict the occupier or manager.

102. Power of Court to make orders.—(1) Where the occupier or manager of a factory is convicted of an offence punishable under this Act the Court may, in addition to awarding any punishment, by order in writing require him, within a period specified in the order (which the court may, if it thinks fit and on application in such behalf, from time to time extend) to take such measures as may be so specified for remedying the matters in respect of which the offence was committed.

(2) Where an order is made under sub-section (1) the occupier or manager of the factory, as the case may be, shall not be liable under this Act in respect of the continuation of the offence during the period, or extended period, if any, allowed by the Court, but if, on the expiry of such period or extended period, as the case may be, the order or the Court has not been fully complied with, the occupier or manager, as the case may be, shall be deemed to have committed a further offence, and may be sentenced therefore by the Court to undergo imprisonment for a term which may extend to six months or to pay a fine which may extend to one hundred rupees for every day after such expiry on which the order has not been complied with, or both to undergo such imprisonment and to pay such fine, as aforesaid.

103. Presumption as to employment.—If a person is found in a factory at any time, except during intervals for meals or rest, when work is going on or the machinery is in motion, he shall until the contrary is proved, be deemed for the purposes of this Act and the rules made thereunder to have been at that time employed in the factory.

104. Onus as to age.—(1) When any act or omission would, if a person were under a certain age, be an offence punishable under this Act, and such person is in the opinion of the Court prima facie under such age, the burden shall be on the accused to prove that such person is no under such age.

(2) A declaration in writing by a certifying surgeon relating to a worker that he has personally examined him and believes him to be under the age stated is such declaration shall, for the purposes of this Act and the rules made thereunder, be admissible as evidence of the age of that worker.

<sup>1</sup>[104A. Onus of proving limits of what is practicable, etc.—In any proceeding for an offence for the contravention of any provision of this Act or rules made thereunder consisting of a failure to comply with a duty or requirement to do something, it shall be for the person who is alleged to have failed to comply with such duty or requirement, to prove that it was not reasonably practicable or, as the case may be, all practicable measures were taken to satisfy the duty or requirement.]

105. Cognizance of offences.—(1) No Court shall take cognizance of any offence under this Act except on complaint by, or with the previous sanction in writing of, an Inspector.

(2) No Court below that of a Presidency Magistrate or of a Magistrate of the first class shall try any offence punishable under this Act.

106. Limitation of prosecutions.—No Court shall take cognizance of any offence punishable under this Act unless complaint thereof is made within three months of the date on which the alleged commission of the offence came to the knowledge of an Inspector:

Provided that where the offence consists of disobeying a written order made by an Inspector, complaint thereof may be made within six months of the date on which the offence is alleged to have been committed.

<sup>2</sup>[Explanation.—For the purposes of this section,—

(a) in the case of a continuing offence, the period of limitation shall be computed with reference to every point of time during which the offence continues;

(b) where for the performance of any act time is granted or extended on an application made by the occupier or manager of a factory, the period of limitation shall be computed from the date on which the time so granted or extended expired.]

<sup>3</sup>[106A. Jurisdiction of a court for entertaining proceedings, etc., for offence.—For the purposes of conferring jurisdiction on any court in relation to an offence under this Act or the rules made thereunder in connection with the operation of any plant, the place where the plant is for the time being situate shall be deemed to be the place where such offence has been committed.]

## CHAPTER XI

## SUPPLEMENTAL

107. Appeals.—(1) The manager of a factory on whom an order in writing by an Inspector has been served under the provisions of this Act or the occupier of the factory may, within thirty days of the service of the order, appeal against it to the prescribed authority, and such authority may, subject to rules made in this behalf by the State Government, confirm, modify or reverse the order.

(2) Subject to rules made in this behalf by the State Government (which may prescribe classes of appeals which shall not be heard with the aid of assessors), the appellate authority may, or if so required in the petition of appeal shall, hear the appeal with the aid of assessors, one of whom shall be appointed by the appellate authority and the other by such body representing the industry concerned as may be prescribed:

Provided that if no assessor is appointed by such body before the time fixed for hearing the appeal, or if the assessor so appointed fails to attend the hearing at such time, the appellate authority may, unless satisfied that the failure to attend is due to sufficient cause, proceed to hear the appeal without the aid of such assessor or, if it thinks fit, without the aid of any assessor.

(3) Subject to such rules as the Stale Government may make in this behalf and subject to such conditions as to partial compliance or the adoption of temporary measures as the appellate authority may in any case think fit to impose, the appellate authority may, if it thinks fit, suspend the order appealed against pending the decision of the appeal.

108. Display of notices.—(1) In addition to the notices required to be displayed in any factory by or under this Act, there shall be displayed in every factory a notice containing such abstracts of this Act and of the rules made thereunder as may be prescribed and also the name and address of the Inspector and the certifying surgeon.

(2) All notices required by or under this Act to be displayed in a factory shall be in English and in a language understood by the majority of the workers in the factory, and shall be displayed at some conspicuous and convenient place at or near the main entrance to the factory, and shall be maintained in a clean and legible condition.

(3) The Chief Inspector may, by order in writing served on the manager of any factory, require that there shall be displayed in the factory any other notice or poster relating to the health, safety or welfare of the workers in the factory.

109. Service of notices.—The State Government may make rules prescribing the manner of the service of orders under this Act on owners, occupiers or managers of factories.

110. Returns.—The State Government may make rules requiring owners, occupiers or managers of factories to submit such returns, occasional or periodical, as may in its opinion be required for the purposes of this Act.

111. Obligations of workers.—(1) No worker in a factory—

(a) shall wilfully interfere with or misuse any appliance, convenience or other thing provided in a factory for the purposes of securing the health, safety or welfare of the workers therein;

(b) shall wilfully and without reasonable cause do anything likely to endanger himself or others; and

(c) shall wilfully neglect to make use of any appliance or other thing provided in the factory for the purposes of securing the health or safety of the workers therein.

(2) If any worker employed in a factory contravenes any of the provisions of this section or of any rule or order made thereunder, he shall be punishable with imprisonment for a term which may extend to three months, or with fine which may extend to one hundred rupees, or with both.

<sup>1</sup>[111A. Right of workers, etc.—Every worker shall have the right to—

(i) obtain from the occupier, information relating to workers' health and safety at work,

(ii) get trained within the factory wherever possible, or, to get himself sponsored by the occupier for getting trained at a training center or institute, duly approved by the Chief Inspector, where training is imparted for workers' health and safety at work,

(iii) represent to the Inspector directly or through his representative in the matter of inadequate provision for protection of his health or safety in the factory.]

112. General power to make rules.—The State Government may make rules providing for any matter which, under any of the provisions of this Act, is to be or may be prescribed or which may be considered expedient in order to give effect to the purposes of this Act.

113. Powers of Centre to give directions.—The Central Government may give directions to a State Government to the carrying into execution of the provisions of this Act.

114. No charge for facilities and conveniences.—Subject to the provisions of section 46 no fee or charge shall be realised from any worker in respect of any arrangements or facilities to be provided, or any equipments or appliances to be supplied by the occupier under the provisions of this Act.

115. Publication of rules.—<sup>1</sup>[(1)] All rules made under this Act shall be published in the Official Gazette, and shall be subject to the condition of previous publication; and the date to be specified under clause (3) of section 23 of the General Clauses Act, 1897 (10 of 1897), shall be not less than <sup>2</sup>[forty-five days] from the date on which the draft of the proposed rules was published.

<sup>3</sup>[(2) Every rule made by the State Government under this Act shall be laid, as soon as may be after it is made, before the State Legislature.]

116. Application of Act to Government factories.—Unless otherwise provided this Act shall apply to factories belonging to the Central or any State Government.

117. Protection to persons acting under this Act.—No suit, prosecution or other legal proceeding shall lie against any person for anything which is in good faith done or intended to be done under this Act.

118. Restrictions on disclosure of information.—(1) No Inspector shall, while in service or after leaving the service, disclose otherwise than in connection with the execution, or for the purposes, of this Act any information relating to any manufacturing or commercial business or any working process which may come to his knowledge in the course of his official duties.

(2) Nothing in sub-section (1) shall apply to any disclosure of information made with the previous consent in writing of the owner of such business or process or for the purposes of any legal proceeding (including arbitration) pursuant to this Act or of any criminal proceeding which may be taken, whether pursuant to this Act or otherwise, or for the purposes of any report of such proceedings as aforesaid.

(3) If any Inspector contravenes the provisions of sub-section (1) he shall be punishable with imprisonment for a term which may extend to six months, or with fine which may extend to one thousand rupees, or with both.

<sup>4</sup>[118A. Restriction on disclosure of information.—(1) Every Inspector shall treat as confidential the source of any complaint brought to his notice on the breach of any provision of this Act.

(2) No inspector shall, while making an inspection under this Act, disclose to the occupier, manager or his representative that the inspection is made in pursuance of the receipt of a complaint:

Provided that nothing in this sub-section shall apply to any case in which the person who has made the complaint has consented to disclose his name. ]

<sup>5</sup>[119. Act to have effect notwithstanding anything contained in Act 37 of 1970.—The provisions of this Act shall have effect notwithstanding anything inconsistent therewith contained in the Contract Labour (Regulation and Abolition) Act, 1970 <sup>6</sup>[or any other law for the time being in force.]]

120. Repeal and savings.—The enactments set out in the Table appended to this section are hereby repealed:

Provided that anything done under the said enactments which could have been done under this Act if it had then been in force shall be deemed to have been done under this Act.

TABLE.—[Enactments repealed.] Rep. by the Repealing and Amending Act, 1950 (35 of 1950), s. 2 and the First Schedule (w.e.f. 10-4-1950.)

# [THE FIRST SCHEDULE]

[See section 2 (cb)]

## LIST OF INDUSTRIES INVOLVING HAZARDOUS PROCESSES

1. Ferrous Metallurgical industries —Integrated Iron and Steel —Ferrow-alloys —Special Steels

2. Non-ferrous Metallurgical Industries —Primary Metallurgical Industries, namely, size, lead, copper, manganese and aluminium

3. Foundries (ferrous and non-ferrous) —Castings and forgings including cleaning or smoothening/roughening by sand and shot blasting

4. Coal (including coke) industries —Coal Lignite, coke, etc. —Fuel Gases (including Coal Gas, Producer Gas, Water Gas)

5. Power Generating Industries

6. Pulp and paper (including paper products) industries

7. Fertiliser Industries—Nitrogenous—Phosphatic—Mixed

8. Cement Industries —Portland Cement (including slag cement, puzzolona cement and their products)

9. Petroleum industries —Oil Refining —Lubricating Oils and Greases

10. Petro-chemical Industries

11. Drugs and Pharmaceutical Industries —Narcotics, Drugs and Pharmaceutical

12. Fermentation Industries (Distilleries and Breweries)

13. Rubber (Synthetic Industries)

14. Paints and Pigment Industries

15. Leather Tanning Industries

16. Electroplating Industries

17. Chemical Industries

—Coke Oven By-products and Coal tar Distillation products

—Industrial Gases (nitrogen, oxygen, acetylene, argon, carbon dioxide, hydrogen, sulphur dioxide, nitrous oxide halogenated hydrocarbon, ozone, etc.)

—Industrial Carbon

—Alkalies and Acids

—Chromates and dichromates

—Leads and its compounds

—Electro chemicals (metallic sodium, potassium and magnesium, chlorates, perchlorates and peroxides)

—Electro thermal produces (artificial abrasive, calcium carbide)

—Nitrogenous compounds (cyanides, cyanamides, and other nitrogenous compounds)

—Phosphorous and its compounds

—Halogens and Halogenated compounds (Chlorine, Fluorine, Bromine and Iodine)

—Explosives (including industrial explosives and detonators and fuses)

18. Insecticides, Fungicides, Herbicides and other Pesticides Industries

19. Synthetic Resin and Plastics

20. Man-made Fiber (Cellulosic and non-cellulosic) industry

21. Manufacture and repair of electrical accumulators

22. Glass and Ceramics

23. Grinding or glazing of metals

24. Manufacture, handling and processing of asbestos and its products

25. Extraction of oils and fats from vegetable and animal sources

26. Manufacture, handling and use of benzene and substances containing benzene

27. Manufacturing processes and operations involving carbon disulphide

28. Dyes and Dyestuff including their intermediates

29. Highly flammable liquids and gases.

## \*THE SECOND SCHEDULE

## (See section 41 F)

## PERMISSIBLE LEVELS OF CERTAIN CHEMICAL SUBSTANCES IN WORK ENVIRONMENT

<table><tr><td rowspan="2">Substance</td><td colspan="4">Permissible limits of exposure</td></tr><tr><td>Time-weighted average concentration</td><td>(8 hrs)</td><td>Short-term exposure limit (15 min)</td><td></td></tr><tr><td>Acetaldehyde</td><td>ppm</td><td>Mg/m³</td><td>ppm</td><td> $\mathrm { { underline { { M g } / m } } } ^ { 3 }$ </td></tr><tr><td></td><td>100</td><td>180</td><td>150</td><td>270</td></tr><tr><td>Acetic acid.</td><td>10</td><td>25</td><td>15</td><td>37</td></tr><tr><td>Acetone.</td><td>750</td><td>1780</td><td>1000</td><td>2375</td></tr><tr><td>Acrelein.</td><td>0.1 2</td><td>0.25 4.5</td><td>0.3</td><td>0.8</td></tr><tr><td>Acrylonitrile-</td><td></td><td>0.25</td><td></td><td>0.75</td></tr><tr><td>Aldrin-skin</td><td>1</td><td>3</td><td>2</td><td>6</td></tr><tr><td>Allychloride</td><td>0.25</td><td>18</td><td>35</td><td>27</td></tr><tr><td>Ammonia.</td><td>2</td><td>10</td><td>5</td><td>20</td></tr><tr><td>Aniline-Skin Anisidine (o., Pisoners)- -skin.</td><td>0.1</td><td>0.5</td><td></td><td></td></tr><tr><td>Arsenic and compounds (as As) .</td><td></td><td>0.2</td><td></td><td></td></tr><tr><td>Benzene.</td><td>10</td><td>20</td><td>25</td><td>75</td></tr><tr><td>Beryllium</td><td></td><td>0.20</td><td></td><td></td></tr><tr><td>Boron trifluoride.</td><td>0.1</td><td>0.3</td><td></td><td></td></tr><tr><td>Bromine.</td><td>0.1</td><td>0.7</td><td>0.3</td><td>2</td></tr><tr><td>Butane.</td><td>800</td><td>1900</td><td></td><td></td></tr><tr><td>2-Butanone (Methyl-ethyl Ketone-MEK) . .</td><td>200</td><td>590</td><td>300</td><td>885</td></tr><tr><td>n-Butyl acetate.</td><td>150</td><td>710</td><td>200</td><td>950</td></tr><tr><td>n-Butyle alcohol-Skin</td><td>C50</td><td>C150</td><td></td><td></td></tr><tr><td>sec/tert. Butyl acetate.</td><td>200</td><td>950</td><td>250</td><td>1190</td></tr><tr><td>Butyl Mercaptan.</td><td>0.5</td><td>1.5</td><td></td><td></td></tr><tr><td>Cadmium-Dusts and salts (as Cd) .</td><td></td><td>0.05</td><td></td><td>0.2</td></tr><tr><td>Calcium oxide.</td><td></td><td>2</td><td></td><td></td></tr><tr><td>Carbaryl (Sevin)</td><td></td><td>5</td><td></td><td>10</td></tr><tr><td>Carbofuran (Furadan)</td><td></td><td>0.1</td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td></tr><tr><td>Carbon disulphide—Skin.</td><td>10</td><td>30</td><td></td><td></td></tr></table>

\* Ins. by Act 20 of 1987, s. 45 (w.e.f. 1-6-1988).

<table><tr><td></td><td>ppm</td><td>Mg/m3</td><td>ppm</td><td> $\underline { { \mathrm { M g } / \mathrm { m } ^ { 3 } } }$ </td></tr><tr><td>Carbon monoxide).</td><td>50</td><td>40</td><td>400</td><td>440</td></tr><tr><td>Carbon to trachloride—skin</td><td>m5</td><td>30</td><td>20</td><td>125</td></tr><tr><td>Carbonyl Chloride (Phosgene).</td><td>0.1</td><td>0.4</td><td></td><td></td></tr><tr><td>Chlorobenzene (Monochloro-benzene).</td><td>75</td><td>350</td><td></td><td></td></tr><tr><td>Chlordane-skin.</td><td></td><td>0.5</td><td></td><td></td></tr><tr><td>Chlorine</td><td>1</td><td>3</td><td>3</td><td>9</td></tr><tr><td>Chloroform</td><td>10</td><td>50</td><td>50</td><td>225</td></tr><tr><td>Bis-Chloromethyl ether .</td><td>0.001</td><td>0.005</td><td></td><td></td></tr><tr><td>Chromic acid and chromates (as Cr) .</td><td></td><td>0.05</td><td></td><td></td></tr><tr><td>Chromous Salts (as Cr).</td><td></td><td>0.05</td><td></td><td></td></tr><tr><td>Copper fume.</td><td></td><td>0.2</td><td></td><td></td></tr><tr><td>Cotton dust, raw</td><td></td><td>0.2</td><td></td><td>0.6</td></tr><tr><td>Crosol, all isomers—skin .</td><td>5</td><td>22</td><td></td><td></td></tr><tr><td>Cyanides (as CN)—skin .</td><td></td><td>5</td><td></td><td></td></tr><tr><td>Cyanogen .</td><td>10</td><td>20</td><td></td><td></td></tr><tr><td>DDT (Dichlorodiphenyl Trichloroethane) .</td><td></td><td>1</td><td></td><td>3</td></tr><tr><td>demeton-skin</td><td>0.01</td><td>0.1</td><td>0.03</td><td>0.3</td></tr><tr><td>Diazinon-skin</td><td></td><td>0.1</td><td></td><td>0.3</td></tr><tr><td>Dibutyl Phythalate</td><td></td><td>5</td><td></td><td>10</td></tr><tr><td>Dichlorvos (DDVP)—skin .</td><td>0.1</td><td>1</td><td>0.3</td><td>3</td></tr><tr><td>Dieldrin—skin</td><td></td><td>0.25</td><td></td><td>0.75</td></tr><tr><td>Dinitrobenzene (all isomers)—skin .</td><td>0.15</td><td>1</td><td>0.5</td><td>3</td></tr><tr><td>Dinitrotolune-skin</td><td></td><td>1.5</td><td></td><td>5</td></tr><tr><td>Diphenyl</td><td>0.2</td><td>1.5</td><td>0.6</td><td>4</td></tr><tr><td>Endosulfan (Thiodan)—skin .</td><td></td><td>0.1</td><td></td><td>0.4</td></tr><tr><td>Endrin—skin</td><td></td><td>0.1</td><td></td><td>0.3</td></tr><tr><td>Ethyl acetate</td><td>400</td><td>1400</td><td></td><td></td></tr><tr><td>Ethyl alcohol</td><td>1000</td><td>1900</td><td></td><td></td></tr><tr><td>Ethylamine.</td><td>10</td><td>18</td><td></td><td></td></tr><tr><td>Fluorides (as F) </td><td></td><td>2.5</td><td></td><td></td></tr><tr><td>Fluorine .</td><td>1</td><td>2</td><td>2</td><td>4</td></tr><tr><td>Formic Acid</td><td>5</td><td>9</td><td></td><td></td></tr><tr><td>Hydrazine—skin</td><td>0.1</td><td>0.1</td><td></td><td></td></tr><tr><td>Hydrogen Chloride .</td><td>C5</td><td>C7</td><td></td><td></td></tr><tr><td></td><td>ppm</td><td>Mg/m3</td><td>ppm</td><td>Mg/m3</td></tr><tr><td>Hydrogen Cyanide—skin.</td><td>C10</td><td>C10</td><td></td><td></td></tr><tr><td>Hydrogen fluoride (as F) .</td><td>3</td><td>2.5</td><td>6</td><td>5</td></tr><tr><td>Hydrogen Peroxide.</td><td>1</td><td>1.5</td><td>2</td><td>3</td></tr><tr><td>Hydrogen Sulphide.</td><td>10</td><td>14</td><td>15</td><td>21</td></tr><tr><td>Iodine.</td><td>C0.1</td><td>C1</td><td></td><td></td></tr><tr><td>Iron-Oxide Fume (Fez O₃) (as Fe) .</td><td></td><td>5</td><td></td><td>10</td></tr><tr><td>Isoamyl acetate.</td><td>100</td><td>525</td><td>125</td><td>665</td></tr><tr><td>Isoamyl alcohol.</td><td>100</td><td>360</td><td>125</td><td>450</td></tr><tr><td>Isobutyl alcohal.</td><td>50</td><td>150</td><td>75</td><td>225</td></tr><tr><td>Lead, inorg, dusts and fumes (as Pb) .</td><td></td><td>0.15</td><td></td><td>0.45</td></tr><tr><td>Lindane-skin.</td><td></td><td>0.5</td><td></td><td>1.5</td></tr><tr><td>Malathion-skin.</td><td></td><td>10</td><td></td><td></td></tr><tr><td>Manganese (as Mn) dust and compounds.</td><td></td><td>C05</td><td></td><td></td></tr><tr><td>Fume .</td><td></td><td>1</td><td></td><td>0.3</td></tr><tr><td>Mercury (as Hg)—skin Alkyl compounds.</td><td></td><td>0.01</td><td></td><td>0.03</td></tr><tr><td>All forms except alkyl vapour.</td><td></td><td>0.05</td><td></td><td></td></tr><tr><td>Aryl and inorganic compounds.</td><td></td><td>0.1</td><td></td><td></td></tr><tr><td>Methyl alcohol (methanol)—skin.</td><td>200</td><td>260</td><td>250</td><td>310</td></tr><tr><td>Methyl cellosolve—skin (2 methoxy ethanol) .</td><td>5</td><td>16</td><td></td><td></td></tr><tr><td>Methyl isobutyl ketone—skin.</td><td>50</td><td>205</td><td>75</td><td>300</td></tr><tr><td>Methyl Isocyanate.</td><td>0.02</td><td>0.05</td><td></td><td></td></tr><tr><td>Napthalene.</td><td>10</td><td>50</td><td>15</td><td>75</td></tr><tr><td>Nickel carbonyl (as Ni) .</td><td>0.05</td><td>0.35</td><td></td><td></td></tr><tr><td>Nitric acid.</td><td>2</td><td>5</td><td>4</td><td>10</td></tr><tr><td>Nitric oxide. Nitrobenzene—skin.</td><td>25</td><td>30</td><td>35</td><td>45</td></tr><tr><td>Nitrogen dioxide.</td><td>1</td><td>5</td><td>2</td><td>10</td></tr><tr><td>Oil mist, minerals.</td><td>3</td><td>6</td><td>5</td><td>10</td></tr><tr><td>Oxone.</td><td></td><td>5</td><td></td><td>10</td></tr><tr><td></td><td>0.1</td><td>0.2</td><td>0.3</td><td>0.6</td></tr><tr><td>Parathion—skin.</td><td></td><td>0.1</td><td></td><td>0.3</td></tr><tr><td>Phenol—skin.</td><td>5</td><td>19</td><td>10</td><td>38</td></tr><tr><td>Phorate (Thimet)– —skin.</td><td></td><td>0.05</td><td></td><td>0.2</td></tr><tr><td>Phosgene (Carbonyl Chloride) .</td><td>0.1</td><td>0.4</td><td></td><td></td></tr><tr><td>Phosphine.</td><td>0.3</td><td>0.4</td><td>1</td><td>1</td></tr><tr><td></td><td>ppm</td><td>Mg/m³</td><td>ppm</td><td>Mg/m³</td></tr><tr><td>Phosphorus (yellow).</td><td></td><td>0.1</td><td></td><td>0.3</td></tr><tr><td>Phosphorus pentachloride.</td><td>0.1</td><td>1</td><td></td><td></td></tr><tr><td>Phosphorus trichloride.</td><td>0.2</td><td>1.5</td><td>0.5</td><td>3</td></tr><tr><td>Picric acid—skin.</td><td></td><td>0.1</td><td></td><td>0.3</td></tr><tr><td>Pyridine.</td><td>5</td><td>15</td><td>10</td><td>30</td></tr><tr><td>Silane (silicon tetrahydride) .</td><td>5</td><td>7</td><td></td><td></td></tr><tr><td>Sodium hydroxide.</td><td></td><td>C2</td><td></td><td></td></tr><tr><td>Styrene, monomer (phanylethylene) .</td><td>50</td><td>215</td><td>100</td><td>425</td></tr><tr><td>Sulphur dioxide.</td><td>2</td><td>5</td><td>5</td><td>10</td></tr><tr><td>Sulphur hexafluoride.</td><td>1000</td><td>6000</td><td>1250</td><td>7500</td></tr><tr><td>Sulphuric acid.</td><td></td><td>1</td><td></td><td></td></tr><tr><td>Toluene (Toluol) ．．．．.</td><td>100</td><td>375</td><td>150</td><td>560</td></tr><tr><td>0-Toluidinz—skin. ......</td><td>2</td><td>9</td><td></td><td></td></tr><tr><td>Tributyl phosphate. ·．.．.</td><td>0.2</td><td>2.5</td><td>0.4</td><td>5</td></tr><tr><td>Trichloroethylene.</td><td>50</td><td></td><td>270 200</td><td>1080</td></tr><tr><td>Uranium, natural (as U)</td><td></td><td>0.2</td><td></td><td>0.5</td></tr><tr><td>Vinyl chloride .</td><td></td><td>5</td><td>10</td><td></td></tr><tr><td>Welding fumes.</td><td></td><td>5</td><td></td><td></td></tr><tr><td>Xylene (o-, m-, P-isomers)</td><td></td><td>100</td><td>435</td><td>655</td></tr><tr><td>Zirconium compounds (as Zr) .</td><td></td><td></td><td>150 5</td><td>10</td></tr></table>

## C denotes ceiling limit

\*Not more than 4 times a day with at least 60 min. interval between successive exposures.

<table><tr><td>Substance</td><td>Permissible (8 hours)</td><td>time- weighted</td><td></td><td>average concentration</td></tr><tr><td>(i) Silica</td><td></td><td></td><td></td><td></td></tr><tr><td>(a) Crystalline</td><td></td><td></td><td></td><td></td></tr><tr><td>(b) Quartz</td><td></td><td></td><td></td><td></td></tr><tr><td>(1) In term of dusts count</td><td>10600</td><td></td><td></td><td>mppcm</td></tr><tr><td></td><td>% Quartz+10</td><td></td><td></td><td></td></tr><tr><td rowspan="2">(2) In terms of respirable dust</td><td colspan="2">10</td><td></td><td>mg/m³</td></tr><tr><td colspan="2">% respirable quartz+2</td><td></td><td></td></tr><tr><td rowspan="2">(3) In terms of total dust</td><td colspan="2">10</td><td></td><td>mg/m³</td></tr><tr><td colspan="2">% Quartz+3</td><td></td><td></td></tr><tr><td>(ii) Cristobalite (iii) Tridymite</td><td colspan="2">Half the limits given against quartz.</td><td></td><td></td></tr><tr><td></td><td colspan="2">Half the limits given against quartz.</td><td></td><td></td></tr><tr><td>(iv) Silca, fused (v) (a) Tripoli</td><td colspan="2">Same limits as for quartz.</td><td></td><td>Same limit as in formula in item 2 given against</td></tr><tr><td>(b) Amorphous</td><td colspan="2">quartz.</td><td></td><td></td></tr></table>

# <sup>1</sup>[THE THIRD SCHEDULE] (See sections 89 and 90) LIST OF NOTIFIABLE DISEASES

1. Lead poisoning, including poisoning by any preparation or compound of lead or their sequelae.

2. Lead tetra-ethyle poisoning.

3. Phosphorus poisoning or its sequelae.

4. Mercury poisoning or its sequelae.

5. Manganese poisoning or its sequelae.

6. Arsenic poisoning or its sequelae.

7. Poisoning by nitrous fumes.

8. Carbon bisulphide poisoning.

9. Benzene poisoning, including poisoning by any of its homologues, their nitro or amido derivatives or its sequelae.

10. Chrome ulceration or its sequelae.

11. Anthrax.

12. Silicosis.

13. Poisoning by halogens or halogen derivatives of the hydrocarbons of the aliphatic series.

14. Pathological manifestations due to—

(a) radium or other radio-active substances;

(b) X-rays.

15. Primary epitheliomatous cancer of the skin.

16. Toxic anaemia.

17. Toxic jaundice due to poisonous substances.

<sup>1</sup>[18. Oil acne or dermatitis due to mineral oils and compounds containing mineral oil base.

19. Byssionosis.

20. Asbestosis.

21. Occupational or contact dermatitis caused by direct contract with chemicals and paints. These are of two types, that is, primary irritants and allergie sensitizers.

22. Noise induced hearing loss (exposure to high noise levels).]

<sup>2</sup>[23. Beriyllium poisoning.

24. Carbon monoxide.

25. Coal miners’ pnoumoconiosis.

26. Phosgene poisoning.

27. Occupational cancer.

28. Isocyanates poisoning.

29. Taxic nephritis.]