# HEAT TRANSPORTSYSTEM SHUTDOWNOPERATION

## OBJECTIVES:

After completing this module you will be able to:

8.1 Explain the reason why a heat removal path must be available when the unit is shut down.

8.2 Explain the reason for the class of power supply provided for the direct and indirect shutdown cooling systems.

8.3 Explain the operation of the two current types of shutdown cooling systems used in CANDU reactors, ie, indirect and direct

8.4 State the function of the: a) Shutdown Cooling System, b) Maintenance Cooling System.

8.5 Expiain the need for a maintenance cooling system when the method of shutdown cooling is indirect.

8.6 For each of the operating states listed below, label a block diagram that shows the role of the HT system in transferring heat energy (major pathway only) from the heat source to the heat sink.

a) Zero power hot, pressurized when using a direct shutdown cooling system,

b) Zero power hot, pressurized when using an indirect shutdown cooling system,

c) Thermosyphoning,

d) Crash cooldown.

The diagram must show:

i) Major heat sources,

ii) Heat carriers,

↔ Page 2

↔ Page 2

↔Page 3

⇔ Page 4

↔ Pages 3, 8

⇔Page 8

↔ Pages 5-6

↔ Pages 6-7

↔ Pages 9-10

↔ Page 11

## Page 12⇔

iii) Required pumps,

iv) Heat energy transfer points,

v) Heat sinks,

vi) Normal capacity of these systems in terms of percent full power (approximate).

7 a) Explain how thermosyphoning is achieved in a CANDU reactor.

b) State the four conditions required to maintain thermosyphoning.

8.8Explain how, in the absence of the boiler systems as heat sink, an emergency cooldown may be achieved. State the capacity of the system required to perform this emergency cooldown.

8.9 Explain the consequences of violating or exceeding the following constraints:

a) Too frequent use of the shutdown cooling system for emergency cooldowns,

b) Temperatures at which shutdown cooling may be normally valved in.

# INSTRUCTIONAL TEXT

## INTRODUCTION

At power, a significant portion (typically 6-7%) of a CANDU reactor's full power output is due to the heating effects of fission product decay. Following a shutdown of the reactor, these fission products will continue as a thermal power source. Although radioactive decay will decrease the magnitude of this source (typically to about 1% Full Power (FP) in about 1 hour) it will still produce a significant amount of power (\~20-30 MWt, depending on the station).

This unique feature of nuclear powered generating stations requires a heat removal path and heat sink at all times when the reactor contains used fuel. This means that at least a portion of the HTS must be available to remove the decay heat from the fuel.

Since this decay heat is always present, the cooling systems required to remove decay heat are supplied by Class III power (or at least backed up with Class III power) to ensure a reliable power supply (ie. a reliable heat sink).

Without this continuous cooling, it is easily possible to fail fuel even with the reactor shutdown. For example, the massive fuel failures which occurred at Three Mile Island were caused by insufficient cooling of a tripped reactor. Fuel failure will inevitably release fission products into the HTS, reducing the multiple barriers to the release of radioactive contaminants.

This module will deal with the heat removal paths while shutting down the reactor, and while the reactor is shutdown. The emergency use of shutdown cooling and maintenance cooling systems will also be covered.

## TYPES OF SHUTDOWN COOLING SYSTEMS

The systems in use vary between stations and are known either as "directly" cooled or "indirectly" cooled. All make use of at least a portion of the heat transport system with one or more heat exchange points before arriving at the final heat sink (lake, river, or sea).

"Directly cooled" refers to systems where the HT D2O is cooied directly by service water. This type of cooling is used for shutdown cooling in stations where the preheaters are not external to the boiler.

For the "indirectly cooled" case of shutdown cooling, the initial heat exchange is from HTS coolant to boiler feedwater. This heat exchange occurs in preheaters external to the boilers (installed only in some stations), while the boilers themselves are not involved. The second heat exchange is from the feedwater to service water, which carries heat away to the final heat sink (the lake, river, or sea). This is an "indirect" system. Note that this method of cooling requires the boiler feedwater system to be in service, and HT pumps operating.

A separate directiy cooled system, known as the Maintenance Cooling System (MCS) is available on units with indirect shutdown cooling systems. This system allows the feedwater system and HT pumps to be shut down when maintenance on the feedwater or HT system is required. This system has a heat removal capacity of approximately 1% FP.

Partial draining of the HTS (down to header levels) for maintenance purposes may also be performed on some units with direct shutdown cooling systems (or maintenance cooling systems) .

The representative heat removal chains for the above are shown in Figure 8.1 on the next page.

![](images/91931652181bd33f4ea5dbe359969114b5f92c547b7bdff39820d213caed5726.jpg)  
Figure 8.1: Heat Removal Chains

## Steam Reject Cooling

## Obj. 8.4 a) ↔

For both types of systems (direct and indirect), the initial HTS cooldown from full power operation (ie. from 300°C to between 150\*C . 165'C) is normally achieved by Boiler Pressure Control (BPC) system using steam discharge\* to the atmosphere or condenser\*\*. The shutdown cooling system will then continue the cooldown

事 Recall that boiler pressure, hence temperature, is reduced by steam discharge. The HT'S temperature reduces with boiler temperature.

\*\* Further information on steam discharge to the condenser is found in the 234 Turbines course and Module 6 of this course.

It should be noted that steam reject cooling could (theoretically) continue to near 100°C as boiler pressure is lowered, but is no desirable (since the steam volume produced would be enormous). A: the temperature decreases, the rate of HTS cooling would also decreas because the differential temperature between the HTS and the boiler: decreases. The large volumetric flow of steam produced at lower boile pressures may "choke" the steam valves and limit cooldown rate. Thi: would result in spending too much time in the higher risk temperatur range for pressure tube delayed hydride cracking.

## DIRECTLY COOLED SHUTDOWN COOLING SYSTEM

↔ Obj. 8.6 a)

## System Description

A typical system is shown in Figure 8.2 and consists of a pump and heat exchanger combination in parallel with the normal full power heat removal path. The number of shutdown coolers varies from location to location, but there are a minimum of two cooler loops at any location. Note that the normal flow direction through the reactor is maintained by the shutdown cooling pumps. No redundancy of shutdown cooling pumps (in a loop) is provided, as the total shutdown cooling flow is typically 10-15% of the main system flow. Adequate shutdown cooling flow can be maintained with a single shutdown cooling loop unavailable.

On a controlled cooldown, the capacity requirement is for approximately 1-3% of reactor full power.

![](images/6b17dcba33c88b92e9933fc8bc8c8a2f1477d7205434b2c314fff4fce5471567.jpg)  
Figure 8.2: Simplified  
"Directly Cooled" Shutdown Cooling System

## Typical Operation

With the reactor at power, the shutdown cooling isolation valves will be closed. The shutdown cooling loops will be filled with pressurized D2O via small lines from the reactor outlet headers. The shutdown cooling loops are also warmed to a temperature close to the HTS temperature by the use of warmup lines from the HTS (not shown in the diagram), before being slowly valved into service. This avoids thermal shocks to the system.

During a cooldown of the HT system following a reactor shutdown, the shutdown cooling system will be used to cool down the HTS from $\bf \Gamma  { \bf \Gamma } \bf { \Lambda } \tilde { \bf { \Lambda } } \otimes \bf { \bar { \Lambda } } \bf { C }$ to $\mathbf { 6 0 ^ { \circ } C }$ (remember that cooldown from operating temperature to ${ \sim } 1 6 5 ^ { \circ } \mathrm { C }$ is by steam reject). Temperature control of the shutdown cooling system is achieved by automatic control of service water flow through the heat exchangers.(In some plants, 2 or 4 main HT circulating pumps will continue to operate until a low system temperature is achieved. Shutdown cooling can then continue with the HT pumps shut off).

Note that it is important to establish a cooling water flow prior to placing the system in service. Failure to do this could result in boiling on the cooling water side of the heat exchanger. When the cooling water flow is established, the vapour pockets would collapse (due to condensation), which could result in water hammer.

## INDIRECTLY COOLED SHUTDOWN COOLING SYSTEM

## System Description

External preheaters are used at some stations to provide cooler $ { \mathbf { D } } _ { 2 }  { \mathbf { O } }$ to the inner zone of the reactor, where the channel temperature differentials (∆Ts) are higher than those for the outer zone. Other stations use increased coolant flow rate in the channels with higher ∆Ts (inner zone).

In stations with preheaters, coolant for the inner zone channels, which has already passed through the boiler tubes, is routed through the preheater tubes. Here it releases additional heat to preheat the boiler feedwater on the shell side. Thus, pre-cooling of HTS $\mathtt { D 2 O }$ (for the inner zone of the core) and preheating of boiler feedwater are accomplished in the preheater.

The basic system for indirect cooling is shown in Figure 8.3 on the next page. It is somewhat more complicated than the direct method because two heat exchange points are required (refer back to Figure 8.1). The initial heat removal path is from the HT $\mathbf { D } _ { 2 } \mathbf { O }$ to the boiler feedwater in the preheaters, with a secondary heat exchange from the boiler feedwater to service water in the shutdown coolers (heat exchangers).

Note that the system must remove the heat input to the HTS by the main HTS pumps, as well as the decay heat. This increases the heat removal capacity to \~3% FP.

Typically the system consists of 2 x 50% heat exchangers and 2 x 100% pumps. Power supplies are typically Class III to ensure a reliable power source for fuel cooling.

![](images/f3eb544c199f4f480b25c072bd153230df4a4485aed8d63ecdca08c62dd079d9.jpg)  
Figure 8.3: Indirect System for Shutdown Cooling

## Typical Operation

With the reactor at power, the shutdown cooling loop is kept in a cold depressurized state and isolated from the preheaters. The system must be filled and vented prior to use, to prevent water hammer due to slugs of water being forced through the system.

As with the direct system, the shutdown cooling system normally cools the HTS from \~170°C to $\yen 02$

The system is brought into operation by opening the shutdown cooling isolation valves. HTS temperature control is provided by a temperature control valve on the service water line to the heat exchanger.

It is important to keep the feedwater portion of the system pressurized. Failure to do this will result in boiling in the system. The vapour pockets formed will collapse when the vapour is condensed in the heat exchanger, or if the system is pressurized quickly, resulting in water hammer.

Note that the HT pumps must remain in operation to circulate ${ \bf D } _ { 2 } { \bf O }$ through the preheater. Since the HTS is pressurized when the main pumps are in operation, the final state of the HTS under shutdown cooling is cold and pressurized.

Loss of the main HT pumps during a cooldown will result in inadequate heat removal via the preheaters. Thermosyphoning \* will be required to remove the heat that was being removed in the preheater until maintenance cooling is put into service.

## Maintenance Cooling System

As noted earlier, indirect shutdown cooling systems are only suitable to bring the HTS to a cold pressurized state.

The maintenance cooling system is used to take the HTS down to a cold depressurized state.

If maintenance requires the HTS to be depressurized and/or partially drained to header levels, or maintenance is required on the feedwater system, some alternative form of cooling must be provided. The maintenance cooling system will meet this requirement. It's simplified layout is shown in Figure 8.4. Note that only a single loop is used. This loop is physically located at a low level to allow partial draining of the HT system to header level. The system is also capable of cooling the HTS after BPC cooldown under emergency situations (ie. if shutdown cooling is unavailable).

During normal system operation, the maintenance cooling system is isolated from the HTS.

![](images/ef1182b4d34032bda0538a6bc567162c00faa6ab95017e35506284963c1eddf2.jpg)  
Figure 8.4: Typical Maintenance Cooling System

## SUMMARY OF THE KEY CONCEPTS

The HTS must be available at all times to remove decay heat from the fuel due to fission product decay. Power supplies to systems that cool the reactor when shut down are from Class II power, to ensure a reliable power supply.

Direct cooling systems cool the HTS $\mathbf { D _ { 2 } O }$ to provide cooling while shut down. Indirect cooling systems cool the feedwater, which indirectly cools the HTS $\bf { D } _ { 2 } O$ in the preheater.

The shutdown cooling system must remove decay heat to reduce HT temperature from ${ \sim } 1 6 5 ^ { \circ } \mathbf { C } \mathbf { \Lambda } \mathbf { \dot { 1 0 } } \mathbf { \sim } 6 0 ^ { \circ } \mathbf { C } .$ The final state on shutdown cooling is cold and pressurized. Heat removal requirements are \~1-3% of reactor full power for a controlled cooldown. For direct cooling systems, the unit can be depressurized to allow maintenance on the system.

•The maintenance cooling system must remove decay heat to reduce HT temperature from ${ \bf - 6 0 ^ { \circ } C \ t o - 3 0 ^ { \circ } C } .$ The final state on maintenance cooling is cold and depressurized (and possibly drained to header levels). Heat removal requirement is \~1% of reactor full power.

• The maintenance cooling system is capable of cooling the HT system after steam reject cooldown.

## THERMOSYPHONING

At full power operation, Class IV power is required for the main HTS circulating pumps and boiler feed pumps to ensure heat transfer and removal. If Class IV is lost, full power heat transfer capability is also lost and the reactor will trip either on low HT flow or high HT pressure (due to coolant swell, as average HT $\mathtt { D 2 0 }$ temperature increases).

After a loss of Class IV and the resultant reactor trip, some HTS circulation will be maintained by the inertia stored in the HTS pump motors/flywheels for a 2 to 3 minute period. This circulation, although reduced, continues to transport heat from the fuel to the boilers. During this period, the total heat input (fission, decay, and residual pump heat) is reduced to about 3% of full power values. The final heat sink is usually steam discharge to atmosphere via the SRVs or ASDVs (depending on the station).

Following motor/flywheel rundown, heat can still be transported to the boilers by a process of natural convection known as thermosyphoning.

The layout of a CANDU unit ensures that the boilers are at a higher elevation than the reactor. The cooling action in the boiler will increase the density of the $\pmb { \mathrm { D } } _ { 2 } \pmb { 0 }$ coolant causing it to fall back to the

↔ Obj. 8.7 a)

reactor. This will force the hot, lower density, $\bf { D _ { 2 } O }$ to rise from the reactors to the boilers. A continuous flow pattern is thus established.

Cooling can be maintained indefinitely by this process providing the following criteria are maintained:

1. Reactor power is limited to \~3% FP or less (ie. decay heat levels).

2. Boiler Pressure Control is functional to maintain the ∆T between HT $\mathbf { D _ { 2 } O }$ and boiler water. This will ensure that the HT $\mathbf { D } _ { 2 } \mathbf { O }$ density differences are maintained to "drive" the thermosyphoning flows.

3. A boiler heat sink is available, ie, SRVs or ASDVs plus a guaranteed supply of boiler feedwater (supplied by Class II power).

4. HTS pressure and inventory control is operational. If HTS pressure cannot be maintained, boiling may occur in the reactor outlet headers. If excessive boiling were allowed, flow may not be maintainable under two-phase (liquid and vapour) conditions.

The heat transfer paths following loss of Class IV power and under thermosyphoning conditions are shown in Figure 8.5.

(a) Pump Rundown  
![](images/e48c1e02beb115130e4c4bfbcf13d685a1712b5419d4fe8d8f63be65767d6be9.jpg)

(b) Thermosyphoning  
![](images/77a9c6969d362fbf5901eaf7fe4df6fd3972bae28cda7c25ed78bea87e818fb5.jpg)  
Figure 8.5: Heat Transfer Following Loss of Class IV Power

## Crash Cooldown

Crash Cooldown is a procedure which quickly reduces heat transport system temperature following a system upset.

Boiler pressure (hence, boiler temperature) is rapidly reduced by discharging steam to atmosphere using either steam reject valves or instrumented safety valves. The rapid reduction in boiler temperature will cause a corresponding increase in heat transfer rate from the HTS, thus rapidly lowering its temperature.

It should be remembered that this procedure will, as already indicated for emergency cooling using shutdown coolers, subject system components to extreme thermal stresses. A full crash cool, ie. all available steam rejected to atmosphere, would normally only be effected if a LOCA occurs. For other unit upsets, which may require rapid cooling of the HTS, a sufficiently fast cooldown will usually be achievable with less than the full complement of steam discharge valves in use.

The heat transfer path for crash cooldown is shown in Figure 8.6.

![](images/84a67fd74511d5f563089df6daa065b35ac0bf01306a665304233ff856135914.jpg)  
Figure 8.6: Crash Cooldown Heat Transfer Path

## Emergency Cooling Using Shutdown Cooling

If normal cooldown using BPC is not available, emergency cooldown of the HTS (immediately following a trip) can be achieved using only the shutdown coolers by valving in the system without a prior warmup.

The system is designed to withstand the thermal shock which will accompany this procedure, but for a limited number of times only. Extensive repairs, inspections or equipment replacement will be required if this limit is reached.

Following an emergency cooldown, a thorough inspection of the shutdown coolers must be carried out and tube sheet integrity assured.

The normal maximum capacity requirement for the shutdown coolers during an emergency cooldown is \~ 6-7% of full reactor thermal power.

## SUMMARY OF THE KEY CONCEPTS

Thermosyphoning is achieved by natural convection between the reactor and the boilers. In the boilers the $\mathbf { D } _ { 2 } \mathbf { O }$ is cooled by the boiler water and then falls back to the reactor due the increased density of the $\bf { D } _ { 2 } O .$ Hot $\bf { D } _ { 2 } O$ is forced up into the boilers where additional heat can be removed. This method of heat removal is capable of removing ${ \sim } 3 \%$ reactor full power. Four conditions required to maintain thermosyphoning are:

\- Reactor power ≤ 3% FP (ie. decay heat),

\- BPC is functional to maintain ∆T between HT $\mathbf { D } _ { 2 } \mathbf { O }$ and boiler water in the boilers,

\- SRV's or ASDV's are available with a feedwater supply for heat rejection,

HTS pressure and inventory control system available to prevent HTS boiling.

Emergency cooldowns are possible by placing the shutdown cooling system in service at elevated temperatures. Placing this system in service for emergency cooldown subjects the system to high thermal stresses. Inspections of components would be required following an emergency cooldown. The number of times that this system is capable of emergency cooldown is limited. The system capacity required is \~7% reactor full power.

Crash cooldown is a rapid reduction in HTS temperature caused by discharging large amounts of boiler steam to atmosphere.

You can now work on the assignment questions.

## ASSIGNMENT

1. The HTS must be available when the unit is shut down because

2. The shutdown cooling system is supplied by Class  power. The reason for this choice is

3. The operation of direct and indirect types of shutdown cooling systems is as follows:

a) Direct -

b) Indirect -

4. The function of the:

a) Shutdown cooling system is

b) Maintenance cooling system is

5. A maintenance cooling system is provided when the method of shutdown cooling is indirect because

6. For each of the operating states listed below, label the appropriate block diagram (major pathway only) that shows the role of the HTS in transferring heat energy from the heat source to the heat sink.

a) Zero power hot, pressurized when using a direct shutdown cooling system,

b) Zero power hot, pressurized when using an indirect shutdown cooling system,

c) Zero power cold, depressurized when using maintenance cooling,

d) Thermosyphoning,

e) Crash cooldown,

The diagram must show:

i) Major heat sources,

ii) Heat carriers,

iii) Required pumps,

iv) Heat energy transfer points,

v) Heat Sinks,

vi) Normal capacity of the system in terms of percent (approximate) reactor full power.

![](images/1f9952a2f36171bac8e2250c482cbb08d81fe16eb439dbeb97f5f47b438f141d.jpg)

![](images/daa55df577fab0dc3c3c5310e01e358c4a3aa91f3c311475c3b703b0d0d2d411.jpg)

![](images/1c9303570ff0f2ff80f21e4eb1474cdf65f6e50bac710c5e0636b770fa7414e6.jpg)

![](images/cecf3f5c29c326f8efe67d8ff8e35e9373905c1b8afa57f0b4c907cd638517a5.jpg)

7. Thermosyphoning is a valid method of heat removal from a CANDU reactor.

a) Thermosyphoning is achieved by:

Crash Cooldown

b) What four criteria must be met / maintained to ensure the viability of thermosyphoning?

i)

ii)

iii)

iv)

8. Explain how an emergency cooldown may be achieved without using the boiler system.

9. Explain the constraints and consequences of the following:

a) Valving in shutdown cooling at high temperatures,

b) Too frequent usage of the shutdown cooling system for emergency cooldowns.

## Before you move on, review the objectives and make sure that you can meet their requirements.

Prepared by: D. Tennant, N. Ritter, WNTD

Revised by: P. Bird, WNTD

Revision date: June, 1992